import { useState, useEffect } from 'react'
import { Search, TrendingUp, Globe, Zap, Star, Clock, ShoppingCart, Filter, ArrowUpDown } from 'lucide-react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Separator } from '@/components/ui/separator.jsx'
import './App.css'

const API_BASE_URL = 'https://60h5imclkgvv.manus.space/api'

function App() {
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState(null)
  const [loading, setLoading] = useState(false)
  const [currency, setCurrency] = useState('USD')
  const [country, setCountry] = useState('US')
  const [suggestions, setSuggestions] = useState([])
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [platforms, setPlatforms] = useState([])

  // Load supported platforms on component mount
  useEffect(() => {
    fetchPlatforms()
  }, [])

  // Fetch search suggestions as user types
  useEffect(() => {
    if (searchQuery.length >= 2) {
      fetchSuggestions(searchQuery)
    } else {
      setSuggestions([])
      setShowSuggestions(false)
    }
  }, [searchQuery])

  const fetchPlatforms = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/platforms`)
      const data = await response.json()
      setPlatforms(data.platforms || [])
    } catch (error) {
      console.error('Error fetching platforms:', error)
    }
  }

  const fetchSuggestions = async (query) => {
    try {
      const response = await fetch(`${API_BASE_URL}/search-suggestions?q=${encodeURIComponent(query)}`)
      const data = await response.json()
      setSuggestions(data.suggestions || [])
      setShowSuggestions(data.suggestions.length > 0)
    } catch (error) {
      console.error('Error fetching suggestions:', error)
    }
  }

  const handleSearch = async (query = searchQuery) => {
    if (!query.trim()) return

    setLoading(true)
    setShowSuggestions(false)
    
    try {
      const params = new URLSearchParams({
        q: query,
        currency: currency,
        country: country,
        max_results: '3',
        include_shipping: 'true',
        include_taxes: 'true'
      })

      const response = await fetch(`${API_BASE_URL}/smart-search?${params}`)
      const data = await response.json()
      
      if (response.ok) {
        setSearchResults(data)
      } else {
        console.error('Search error:', data.error)
      }
    } catch (error) {
      console.error('Search failed:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSuggestionClick = (suggestion) => {
    setSearchQuery(suggestion)
    setShowSuggestions(false)
    handleSearch(suggestion)
  }

  const formatCurrency = (amount, currencyCode) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currencyCode
    }).format(amount)
  }

  const getTrustScoreColor = (score) => {
    if (score >= 80) return 'text-green-600'
    if (score >= 60) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getPlatformLogo = (platform) => {
    const logos = {
      'Amazon': '🛒',
      'eBay': '🏪',
      'AliExpress': '🏮',
      'Walmart': '🏬',
      'Best Buy': '💻',
      'Temu': '🎁',
      'Shein': '👗'
    }
    return logos[platform] || '🛍️'
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  PricePulse
                </h1>
                <p className="text-xs text-gray-500">Global Price Comparison</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger className="w-20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="GBP">GBP</SelectItem>
                  <SelectItem value="JPY">JPY</SelectItem>
                  <SelectItem value="CAD">CAD</SelectItem>
                  <SelectItem value="AUD">AUD</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={country} onValueChange={setCountry}>
                <SelectTrigger className="w-16">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="US">🇺🇸 US</SelectItem>
                  <SelectItem value="GB">🇬🇧 UK</SelectItem>
                  <SelectItem value="DE">🇩🇪 DE</SelectItem>
                  <SelectItem value="FR">🇫🇷 FR</SelectItem>
                  <SelectItem value="CA">🇨🇦 CA</SelectItem>
                  <SelectItem value="AU">🇦🇺 AU</SelectItem>
                  <SelectItem value="ZA">🇿🇦 ZA</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        {!searchResults && (
          <div className="text-center py-16">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Find the Best Prices Across
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Global Platforms</span>
              </h2>
              <p className="text-xl text-gray-600 mb-8">
                Compare prices from Amazon, eBay, AliExpress, and more. Get total costs including shipping, taxes, and duties.
              </p>
              
              <div className="flex flex-wrap justify-center gap-4 mb-8">
                <Badge variant="secondary" className="flex items-center gap-2">
                  <Globe className="w-4 h-4" />
                  {platforms.length}+ Platforms
                </Badge>
                <Badge variant="secondary" className="flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  Real-time Prices
                </Badge>
                <Badge variant="secondary" className="flex items-center gap-2">
                  <ShoppingCart className="w-4 h-4" />
                  Total Cost Calculator
                </Badge>
              </div>
            </div>
          </div>
        )}

        {/* Search Section */}
        <div className="relative max-w-2xl mx-auto mb-8">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Search for products (e.g., iPhone 15, wireless headphones, gaming laptop)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              className="pl-12 pr-4 py-6 text-lg rounded-xl border-2 border-gray-200 focus:border-blue-500 transition-colors"
            />
            <Button 
              onClick={() => handleSearch()}
              disabled={loading || !searchQuery.trim()}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 px-6 py-2 rounded-lg bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                'Search'
              )}
            </Button>
          </div>
          
          {/* Search Suggestions */}
          {showSuggestions && suggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-lg shadow-lg border border-gray-200 z-40">
              {suggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="w-full text-left px-4 py-3 hover:bg-gray-50 first:rounded-t-lg last:rounded-b-lg transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Search className="w-4 h-4 text-gray-400" />
                    <span>{suggestion}</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Search Results */}
        {searchResults && (
          <div className="space-y-8">
            {/* Search Summary */}
            <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-2xl">Search Results for "{searchResults.query}"</CardTitle>
                    <CardDescription className="text-lg">
                      Found {searchResults.total_products} products across {searchResults.search_metadata?.platforms_with_results || 0} platforms
                      in {searchResults.search_duration_seconds}s
                    </CardDescription>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-gray-500">Best Deal</div>
                    <div className="text-2xl font-bold text-green-600">
                      {searchResults.price_insights?.price_range ? 
                        formatCurrency(searchResults.price_insights.price_range.min, currency) : 'N/A'}
                    </div>
                  </div>
                </div>
              </CardHeader>
            </Card>

            {/* Recommendations */}
            {searchResults.recommendations && searchResults.recommendations.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="w-5 h-5 text-yellow-500" />
                    Smart Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {searchResults.recommendations.map((rec, index) => (
                      <div key={index} className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg">
                        <div className="w-6 h-6 bg-yellow-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                          {index + 1}
                        </div>
                        <p className="text-gray-700">{rec}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Results Tabs */}
            <Tabs defaultValue="grouped" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="grouped">Grouped Results</TabsTrigger>
                <TabsTrigger value="best-deals">Best Deals</TabsTrigger>
                <TabsTrigger value="insights">Price Insights</TabsTrigger>
              </TabsList>

              {/* Grouped Results */}
              <TabsContent value="grouped" className="space-y-6">
                {searchResults.matched_groups && searchResults.matched_groups.map((group, groupIndex) => (
                  <Card key={groupIndex}>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold">
                          {groupIndex + 1}
                        </div>
                        Similar Products ({group.group_size} items)
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                        {group.products.map((product, productIndex) => (
                          <Card key={productIndex} className="hover:shadow-lg transition-shadow">
                            <CardContent className="p-4">
                              <div className="flex items-start gap-3 mb-3">
                                <div className="text-2xl">{getPlatformLogo(product.platform)}</div>
                                <div className="flex-1 min-w-0">
                                  <h4 className="font-semibold text-sm line-clamp-2 mb-1">
                                    {product.display_name || product.name}
                                  </h4>
                                  <Badge variant="outline" className="text-xs">
                                    {product.platform}
                                  </Badge>
                                </div>
                              </div>
                              
                              <div className="space-y-2">
                                <div className="flex items-center justify-between">
                                  <span className="text-sm text-gray-500">Total Cost:</span>
                                  <span className="font-bold text-lg">
                                    {formatCurrency(product.total_cost, product.user_currency || currency)}
                                  </span>
                                </div>
                                
                                {product.cost_breakdown && (
                                  <div className="text-xs text-gray-500 space-y-1">
                                    <div className="flex justify-between">
                                      <span>Base Price:</span>
                                      <span>{formatCurrency(product.cost_breakdown.base_price, product.user_currency || currency)}</span>
                                    </div>
                                    {product.cost_breakdown.shipping_cost > 0 && (
                                      <div className="flex justify-between">
                                        <span>Shipping:</span>
                                        <span>{formatCurrency(product.cost_breakdown.shipping_cost, product.user_currency || currency)}</span>
                                      </div>
                                    )}
                                    {(product.cost_breakdown.vat_amount + product.cost_breakdown.import_duty) > 0 && (
                                      <div className="flex justify-between">
                                        <span>Taxes & Duties:</span>
                                        <span>{formatCurrency(product.cost_breakdown.vat_amount + product.cost_breakdown.import_duty, product.user_currency || currency)}</span>
                                      </div>
                                    )}
                                  </div>
                                )}
                                
                                <div className="flex items-center justify-between pt-2">
                                  <div className="flex items-center gap-2">
                                    {product.rating && (
                                      <div className="flex items-center gap-1">
                                        <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                        <span className="text-xs">{product.rating}</span>
                                      </div>
                                    )}
                                    {product.trust_score && (
                                      <Badge variant="outline" className={`text-xs ${getTrustScoreColor(product.trust_score)}`}>
                                        {product.trust_score}% Trust
                                      </Badge>
                                    )}
                                  </div>
                                  
                                  <div className="flex items-center gap-1 text-xs text-gray-500">
                                    <Clock className="w-3 h-3" />
                                    <span>{product.delivery_estimate || 'Unknown'}</span>
                                  </div>
                                </div>
                                
                                {product.product_url && (
                                  <Button 
                                    size="sm" 
                                    className="w-full mt-3"
                                    onClick={() => window.open(product.product_url, '_blank')}
                                  >
                                    View Product
                                  </Button>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              {/* Best Deals */}
              <TabsContent value="best-deals" className="space-y-4">
                {searchResults.best_deals && searchResults.best_deals.map((deal, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                          #{index + 1}
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="font-semibold text-lg mb-1">
                                {deal.display_name || deal.name}
                              </h3>
                              <div className="flex items-center gap-3 mb-2">
                                <Badge className="bg-blue-100 text-blue-800">
                                  {getPlatformLogo(deal.platform)} {deal.platform}
                                </Badge>
                                {deal.confidence_level && (
                                  <Badge variant="outline" className={
                                    deal.confidence_level === 'high' ? 'border-green-500 text-green-700' :
                                    deal.confidence_level === 'medium' ? 'border-yellow-500 text-yellow-700' :
                                    'border-red-500 text-red-700'
                                  }>
                                    {deal.confidence_level} confidence
                                  </Badge>
                                )}
                              </div>
                            </div>
                            
                            <div className="text-right">
                              <div className="text-3xl font-bold text-green-600">
                                {formatCurrency(deal.total_cost, deal.user_currency || currency)}
                              </div>
                              {deal.cost_breakdown && (
                                <div className="text-sm text-gray-500">
                                  Base: {formatCurrency(deal.cost_breakdown.base_price, deal.user_currency || currency)}
                                </div>
                              )}
                            </div>
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4 text-sm text-gray-600">
                              {deal.rating && (
                                <div className="flex items-center gap-1">
                                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                  <span>{deal.rating}/5</span>
                                </div>
                              )}
                              <div className="flex items-center gap-1">
                                <Clock className="w-4 h-4" />
                                <span>{deal.delivery_estimate || 'Unknown delivery'}</span>
                              </div>
                            </div>
                            
                            {deal.product_url && (
                              <Button 
                                onClick={() => window.open(deal.product_url, '_blank')}
                                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                              >
                                Get This Deal
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              {/* Price Insights */}
              <TabsContent value="insights" className="space-y-6">
                {searchResults.price_insights && (
                  <>
                    <Card>
                      <CardHeader>
                        <CardTitle>Price Analysis</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div className="text-center p-4 bg-green-50 rounded-lg">
                            <div className="text-2xl font-bold text-green-600">
                              {formatCurrency(searchResults.price_insights.price_range?.min || 0, currency)}
                            </div>
                            <div className="text-sm text-gray-600">Lowest Price</div>
                          </div>
                          <div className="text-center p-4 bg-red-50 rounded-lg">
                            <div className="text-2xl font-bold text-red-600">
                              {formatCurrency(searchResults.price_insights.price_range?.max || 0, currency)}
                            </div>
                            <div className="text-sm text-gray-600">Highest Price</div>
                          </div>
                          <div className="text-center p-4 bg-blue-50 rounded-lg">
                            <div className="text-2xl font-bold text-blue-600">
                              {formatCurrency(searchResults.price_insights.price_range?.average || 0, currency)}
                            </div>
                            <div className="text-sm text-gray-600">Average Price</div>
                          </div>
                          <div className="text-center p-4 bg-purple-50 rounded-lg">
                            <div className="text-2xl font-bold text-purple-600">
                              {searchResults.price_insights.savings_potential?.percentage || 0}%
                            </div>
                            <div className="text-sm text-gray-600">Max Savings</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {searchResults.price_insights.platform_analysis && (
                      <Card>
                        <CardHeader>
                          <CardTitle>Platform Comparison</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            {Object.entries(searchResults.price_insights.platform_analysis).map(([platform, stats]) => (
                              <div key={platform} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                                <div className="flex items-center gap-3">
                                  <span className="text-2xl">{getPlatformLogo(platform)}</span>
                                  <div>
                                    <div className="font-semibold">{platform}</div>
                                    <div className="text-sm text-gray-600">{stats.count} products found</div>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <div className="font-bold">
                                    {formatCurrency(stats.avg_price || 0, currency)}
                                  </div>
                                  <div className="text-sm text-gray-600">Average</div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </>
                )}
              </TabsContent>
            </Tabs>
          </div>
        )}

        {/* Platform Showcase */}
        {!searchResults && platforms.length > 0 && (
          <Card className="mt-16">
            <CardHeader>
              <CardTitle className="text-center">Supported Platforms</CardTitle>
              <CardDescription className="text-center">
                We search across {platforms.length} major e-commerce platforms to find you the best deals
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
                {platforms.map((platform, index) => (
                  <div key={index} className="text-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <div className="text-3xl mb-2">{getPlatformLogo(platform.name)}</div>
                    <div className="font-semibold text-sm">{platform.name}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      Trust: {platform.trust_score}%
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold">PricePulse</h3>
            </div>
            <p className="text-gray-400 mb-6">
              The world's most comprehensive price comparison platform
            </p>
            <div className="flex justify-center space-x-8 text-sm text-gray-400">
              <span>Real-time Price Tracking</span>
              <span>Global Currency Support</span>
              <span>Total Cost Calculator</span>
              <span>Smart Recommendations</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App
