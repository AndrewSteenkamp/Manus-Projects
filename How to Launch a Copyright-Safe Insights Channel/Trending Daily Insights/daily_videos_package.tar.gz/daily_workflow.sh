#!/bin/bash
# DAILY VIDEO WORKFLOW - Run this every morning

echo "🌅 Starting daily video generation for Trending Daily Insights..."
echo ""

# Generate today's videos
python3.11 simple_video_generator_no_openai.py

echo ""
echo "✅ Videos generated!"
echo "📋 Next: Check daily_videos folder and follow INSTRUCTIONS files"
echo "🎬 Upload to YouTube when ready"
echo "💰 Start earning revenue!"
