# Autonomous YouTube Agent 🤖

A complete agentic system that operates your YouTube channel as a fully autonomous product. The agent handles everything from research to upload without human intervention.

## 🚀 Quick Start

```bash
# 1. Run setup
python setup.py

# 2. Configure API keys
cp config/api_keys_template.json config/api_keys.json
# Edit config/api_keys.json with your actual API keys

# 3. Test the system
python autonomous_agent_system.py --dev-mode

# 4. Start autonomous operation
python autonomous_agent_system.py --daemon
```

## ✨ Features

- **🔄 Fully Autonomous** - Runs 24/7 without human input
- **🧠 Self-Optimizing** - Learns from performance and adjusts strategy
- **🛡️ Error Recovery** - Handles failures and continues operation
- **📊 Multi-Source Research** - Aggregates from dozens of sources
- **🎯 Professional Content** - Generates expert-level analysis
- **📈 SEO Optimization** - Automatically optimizes for discovery
- **📋 Performance Tracking** - Monitors and improves metrics

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                 Master Agent Controller                     │
├─────────────────────────────────────────────────────────────┤
│  Research Agent  │  Content Agent  │  Video Agent           │
│  • News scraping │  • Script gen   │  • NotebookLM          │
│  • Trend analysis│  • SEO optimize │  • Video creation      │
│  • Expert quotes │  • Quality check│  • Branding            │
├─────────────────────────────────────────────────────────────┤
│  Upload Agent    │  Analytics Agent                         │
│  • YouTube API   │  • Performance tracking                  │
│  • Scheduling    │  • Optimization recommendations          │
│  • Metadata      │  • A/B testing                          │
└─────────────────────────────────────────────────────────────┘
```

## 📋 Prerequisites

### Required APIs
- **YouTube Data API v3** - For uploads and analytics
- **NotebookLM API** - For AI video generation  
- **News APIs** - For research automation
- **OpenAI API** - For content optimization

### System Requirements
- Python 3.8+
- 4GB RAM minimum
- 50GB storage for video files
- Stable internet connection

## 🛠️ Installation

### Method 1: Automated Setup (Recommended)
```bash
python setup.py
```

### Method 2: Manual Setup
```bash
# Install dependencies
pip install -r requirements.txt

# Create directories
mkdir -p {config,logs,output,cache,templates,assets}

# Copy configuration templates
python -c "import json; json.dump({}, open('config/agent_config.json', 'w'))"
```

## ⚙️ Configuration

### 1. API Keys (`config/api_keys.json`)
```json
{
  "youtube": {
    "api_key": "YOUR_YOUTUBE_API_KEY",
    "client_id": "YOUR_CLIENT_ID",
    "client_secret": "YOUR_CLIENT_SECRET"
  },
  "notebooklm": {
    "api_key": "YOUR_NOTEBOOKLM_KEY"
  },
  "openai": {
    "api_key": "YOUR_OPENAI_KEY"
  }
}
```

### 2. Agent Settings (`config/agent_config.json`)
```json
{
  "agent_settings": {
    "daily_schedule": "08:00",
    "timezone": "UTC",
    "autonomous_mode": true
  },
  "channel_config": {
    "channel_id": "YOUR_CHANNEL_ID",
    "niche": "Geopolitical Analysis"
  },
  "automation_config": {
    "auto_research": true,
    "auto_upload": true,
    "auto_optimization": true
  }
}
```

## 🎮 Operation Modes

### Full Autonomous Mode
```bash
python autonomous_agent_system.py --daemon
```
- Complete hands-off operation
- Daily content creation and upload
- Automatic optimization
- Error recovery

### Development Mode
```bash
python autonomous_agent_system.py --dev-mode
```
- Single workflow execution
- Detailed logging
- No actual uploads (dry run)
- Perfect for testing

### Semi-Autonomous Mode
```bash
python autonomous_agent_system.py --daemon --approval-required
```
- Creates content automatically
- Requires human approval before upload
- Good for initial testing

## 📊 Monitoring

### Web Dashboard
Access at `http://localhost:8080`:
- Real-time agent status
- Performance metrics
- Content preview
- Configuration management

### Log Files
```bash
# Real-time monitoring
tail -f logs/agent.log

# Performance tracking
tail -f logs/performance.log

# Error monitoring
tail -f logs/errors.log
```

## 🚀 Deployment Options

### Local Development
```bash
python autonomous_agent_system.py --daemon
```

### Cloud Deployment (AWS)
```bash
# Launch EC2 instance
aws ec2 run-instances --image-id ami-0abcdef1234567890 --instance-type t3.medium

# Setup and deploy
scp -r . ec2-user@your-instance:/home/ec2-user/agent/
ssh ec2-user@your-instance
cd agent && python setup.py
sudo systemctl enable youtube-agent.service
```

### Docker Deployment
```bash
docker build -t youtube-agent .
docker run -d --name youtube-agent youtube-agent
```

## 📈 Expected Results

| Timeframe | Expected Outcome |
|-----------|------------------|
| Week 1    | 7 videos uploaded automatically |
| Month 1   | 30+ consistent uploads, baseline metrics |
| Month 3   | Optimized performance, growing audience |
| Month 6   | Established daily source, multiple revenue streams |

## 🔧 Customization

### Research Sources
Edit `config/research_sources.json`:
```json
{
  "primary_sources": [
    "reuters.com/world",
    "apnews.com/hub/russia-ukraine"
  ],
  "keywords": [
    "Ukraine war updates",
    "geopolitical analysis"
  ]
}
```

### Content Templates
Customize `templates/script_template.md`:
```markdown
# Daily Brief - {{date}}
## {{main_topic}}
{{analysis}}
```

## 🛠️ Troubleshooting

### Common Issues

**Agent Won't Start**
```bash
# Check configuration
python -c "import json; print(json.load(open('config/agent_config.json')))"

# Verify API keys
python test_apis.py
```

**Low Performance**
- Agent automatically optimizes based on metrics
- Check `logs/optimization.log` for adjustments
- Review performance targets in config

**Upload Failures**
- Built-in retry mechanisms active
- Check YouTube API quotas
- Review `logs/upload_errors.log`

### Emergency Controls
```bash
# Stop immediately
pkill -f autonomous_agent_system.py

# Pause uploads only
echo "PAUSE_UPLOADS" > control/agent_commands.txt

# Resume operations  
echo "RESUME" > control/agent_commands.txt
```

## 📚 Documentation

- `agent_deployment_guide.md` - Complete deployment guide
- `notebooklm_setup_guide.md` - NotebookLM integration details
- `api_documentation.md` - API reference
- `troubleshooting.md` - Common issues and solutions

## 🤝 Support

For issues and questions:
1. Check the troubleshooting guide
2. Review log files for errors
3. Test in development mode first
4. Verify API keys and quotas

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🚨 Important Notes

- **Test thoroughly** in development mode before production
- **Monitor performance** regularly through the dashboard
- **Keep API keys secure** and never commit them to version control
- **Backup configurations** before making changes
- **Review content quality** periodically to ensure standards

---

**Ready to launch your autonomous YouTube channel? Run `python setup.py` to get started! 🚀**

