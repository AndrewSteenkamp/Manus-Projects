'''Main application file'''

from flask import Flask, render_template, request, jsonify
from agents.finance.finance_agent import FinanceAgent
from agents.legal.legal_agent import LegalAgent
from agents.operations.operations_agent import OperationsAgent

app = Flask(__name__)

# Initialize agents
finance_agent = FinanceAgent(name="CFO", role="Chief Financial Officer")
legal_agent = LegalAgent(name="CLO", role="Chief Legal Officer")
operations_agent = OperationsAgent(name="COO", role="Chief Operating Officer")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/execute_task', methods=['POST'])
def execute_task():
    data = request.get_json()
    agent = data.get('agent')
    task = data.get('task')

    if agent == 'finance':
        result = finance_agent.execute_task(task)
        return jsonify({'result': result})
    elif agent == 'legal':
        result = legal_agent.execute_task(task)
        return jsonify({'result': result})
    elif agent == 'operations':
        result = operations_agent.execute_task(task)
        return jsonify({'result': result})
    else:
        return jsonify({'error': 'Unknown agent'})

if __name__ == '__main__':
    app.run(debug=True)

