"""
Core AI Agent Framework with Real Intelligence
This is the foundation for all autonomous agents in the system.
"""

import os
import json
from datetime import datetime
from openai import OpenAI

class BaseAgent:
    """
    Base class for all AI agents with real LLM-powered intelligence.
    Each agent has memory, can make decisions, and execute tasks autonomously.
    """
    
    def __init__(self, name, role, department, model="gpt-4.1-mini"):
        self.name = name
        self.role = role
        self.department = department
        self.model = model
        self.client = OpenAI()  # API key already configured in environment
        self.memory = []
        self.task_history = []
        
    def think(self, context, task):
        """
        Use LLM to analyze context and decide on action.
        This is where the real AI intelligence happens.
        """
        system_prompt = f"""You are {self.name}, a {self.role} in the {self.department} department.
You are an expert in your field and make autonomous decisions.
Your goal is to complete tasks efficiently and professionally.

Previous context: {json.dumps(self.memory[-5:] if self.memory else [])}
"""
        
        user_prompt = f"""Task: {task}
Context: {context}

Analyze this task and provide:
1. Your understanding of what needs to be done
2. The specific actions you will take
3. Expected outcome

Respond in JSON format:
{{
    "understanding": "what you understand",
    "actions": ["action1", "action2"],
    "expected_outcome": "what you expect to achieve"
}}
"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.7
            )
            
            decision = json.loads(response.choices[0].message.content)
            self.memory.append({
                "timestamp": datetime.now().isoformat(),
                "task": task,
                "decision": decision
            })
            
            return decision
            
        except Exception as e:
            return {
                "understanding": f"Error in thinking process: {str(e)}",
                "actions": ["log_error", "request_help"],
                "expected_outcome": "Need human intervention"
            }
    
    def execute_task(self, task, context=None):
        """
        Execute a task using AI-powered decision making.
        """
        # Think about the task
        decision = self.think(context or {}, task)
        
        # Log the task
        task_record = {
            "timestamp": datetime.now().isoformat(),
            "task": task,
            "decision": decision,
            "status": "in_progress"
        }
        
        # Execute based on decision
        result = self._execute_actions(decision["actions"], context)
        
        task_record["status"] = "completed"
        task_record["result"] = result
        self.task_history.append(task_record)
        
        return result
    
    def _execute_actions(self, actions, context):
        """
        Execute the list of actions determined by the AI.
        Override this in subclasses for specific implementations.
        """
        results = []
        for action in actions:
            results.append(f"Executed: {action}")
        return results
    
    def delegate_to(self, other_agent, task, context=None):
        """
        Delegate a task to another agent.
        This enables cross-department collaboration.
        """
        delegation_record = {
            "from": self.name,
            "to": other_agent.name,
            "task": task,
            "timestamp": datetime.now().isoformat()
        }
        
        result = other_agent.execute_task(task, context)
        delegation_record["result"] = result
        
        self.memory.append(delegation_record)
        return result
    
    def learn_from_feedback(self, feedback):
        """
        Store feedback to improve future performance.
        """
        self.memory.append({
            "type": "feedback",
            "content": feedback,
            "timestamp": datetime.now().isoformat()
        })
    
    def get_status(self):
        """
        Return current status and recent activity.
        """
        return {
            "name": self.name,
            "role": self.role,
            "department": self.department,
            "tasks_completed": len(self.task_history),
            "recent_tasks": self.task_history[-5:] if self.task_history else [],
            "memory_size": len(self.memory)
        }
