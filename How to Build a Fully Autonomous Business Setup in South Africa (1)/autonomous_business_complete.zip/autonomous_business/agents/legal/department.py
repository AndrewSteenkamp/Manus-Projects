"""
Complete Legal Department Hierarchy
CLO → Corporate Lawyer → Compliance Officer
"""

import sys
sys.path.append('/home/ubuntu/autonomous_business')

from core.base_agent import BaseAgent
import json
from datetime import datetime

class CLOAgent(BaseAgent):
    """
    Chief Legal Officer - Top of legal hierarchy
    Handles legal strategy and major decisions
    """
    
    def __init__(self):
        super().__init__(
            name="CLO",
            role="Chief Legal Officer",
            department="Legal"
        )
        
    def _execute_actions(self, actions, context):
        results = []
        for action in actions:
            if "contract" in action.lower():
                results.append(self.review_major_contract(context))
            elif "risk" in action.lower():
                results.append(self.assess_legal_risk(context))
            elif "strategy" in action.lower():
                results.append(self.develop_legal_strategy(context))
            else:
                results.append(f"Executed: {action}")
        return results
    
    def review_major_contract(self, context):
        """Review high-value contracts"""
        contract_type = context.get("type", "service_agreement")
        value = context.get("value", 0)
        
        prompt = f"""Review this contract for legal risks (South African law):

Type: {contract_type}
Value: R{value}
Parties: {context.get('parties', 'Unknown')}

Identify:
1. Key legal risks
2. Liability concerns
3. Compliance issues
4. Recommended changes
5. SA-specific considerations

Respond in JSON format."""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a CLO expert in South African business law."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3
            )
            
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            return {"error": str(e)}
    
    def assess_legal_risk(self, context):
        """Assess legal risk of business decision"""
        decision = context.get("decision", "")
        
        prompt = f"""Assess legal risk of this business decision (SA law):

Decision: {decision}

Provide:
1. Risk level (Low/Medium/High)
2. Specific legal concerns
3. Regulatory implications
4. Mitigation strategies
5. Recommended action

Respond in JSON format."""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a CLO assessing legal risks."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3
            )
            
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            return {"error": str(e)}
    
    def develop_legal_strategy(self, context):
        """Develop legal strategy for business initiative"""
        return {
            "type": "legal_strategy",
            "status": "developed",
            "timestamp": datetime.now().isoformat()
        }


class CorporateLawyer(BaseAgent):
    """
    Corporate Lawyer - Reports to CLO
    Handles contracts, agreements, and legal documents
    """
    
    def __init__(self, clo):
        super().__init__(
            name="Corporate Lawyer",
            role="Corporate Lawyer",
            department="Legal"
        )
        self.clo = clo
        self.contracts_drafted = []
        
    def _execute_actions(self, actions, context):
        results = []
        for action in actions:
            if "draft" in action.lower():
                results.append(self.draft_contract(context))
            elif "review" in action.lower():
                results.append(self.review_contract(context))
            elif "nda" in action.lower():
                results.append(self.create_nda(context))
            else:
                results.append(f"Executed: {action}")
        return results
    
    def draft_contract(self, context):
        """Draft legal contract"""
        contract_type = context.get("type", "service_agreement")
        parties = context.get("parties", {})
        
        prompt = f"""Draft a {contract_type} contract for South Africa:

Party A: {parties.get('party_a', 'Company')}
Party B: {parties.get('party_b', 'Client')}
Scope: {context.get('scope', 'Services')}
Value: R{context.get('value', 0)}
Duration: {context.get('duration', '6 months')}

Include:
1. Parties and definitions
2. Scope of work
3. Payment terms
4. Intellectual property
5. Confidentiality
6. Termination clauses
7. Dispute resolution
8. SA law governing clause

Provide contract structure in JSON format."""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a Corporate Lawyer drafting SA contracts."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.4
            )
            
            contract = json.loads(response.choices[0].message.content)
            contract["contract_id"] = f"CONT-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
            contract["drafted_at"] = datetime.now().isoformat()
            
            self.contracts_drafted.append(contract)
            return contract
        except Exception as e:
            return {"error": str(e)}
    
    def review_contract(self, context):
        """Review existing contract"""
        contract_text = context.get("contract", "")
        
        prompt = f"""Review this contract for issues (SA law):

{contract_text[:1000]}

Check for:
1. Unfavorable terms
2. Missing clauses
3. Ambiguous language
4. Compliance issues
5. Risk factors

Respond in JSON with findings."""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a Corporate Lawyer reviewing contracts."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3
            )
            
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            return {"error": str(e)}
    
    def create_nda(self, context):
        """Create Non-Disclosure Agreement"""
        return {
            "type": "NDA",
            "parties": context.get("parties", {}),
            "duration": context.get("duration", "2 years"),
            "jurisdiction": "South Africa",
            "created_at": datetime.now().isoformat()
        }


class ComplianceOfficer(BaseAgent):
    """
    Compliance Officer - Reports to Corporate Lawyer
    Ensures regulatory compliance
    """
    
    def __init__(self, lawyer):
        super().__init__(
            name="Compliance Officer",
            role="Compliance Officer",
            department="Legal"
        )
        self.lawyer = lawyer
        self.compliance_checks = []
        
    def _execute_actions(self, actions, context):
        results = []
        for action in actions:
            if "check" in action.lower() or "audit" in action.lower():
                results.append(self.compliance_audit())
            elif "popia" in action.lower() or "data" in action.lower():
                results.append(self.check_popia_compliance(context))
            elif "register" in action.lower():
                results.append(self.handle_company_registration(context))
            else:
                results.append(f"Executed: {action}")
        return results
    
    def compliance_audit(self):
        """Conduct compliance audit"""
        prompt = """Conduct a compliance audit for a South African business:

Check:
1. CIPC registration status
2. Tax compliance (SARS)
3. POPIA (data protection)
4. B-BBEE requirements
5. Employment law compliance
6. Industry-specific regulations

Provide audit checklist in JSON format."""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a Compliance Officer in South Africa."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3
            )
            
            audit = json.loads(response.choices[0].message.content)
            audit["audit_date"] = datetime.now().isoformat()
            
            self.compliance_checks.append(audit)
            return audit
        except Exception as e:
            return {"error": str(e)}
    
    def check_popia_compliance(self, context):
        """Check POPIA (data protection) compliance"""
        data_practices = context.get("data_practices", "")
        
        prompt = f"""Check POPIA compliance for these data practices:

{data_practices}

Verify:
1. Lawful processing
2. Consent mechanisms
3. Data minimization
4. Storage limitations
5. Security measures
6. Subject rights

Respond in JSON with compliance status."""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a POPIA compliance expert."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3
            )
            
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            return {"error": str(e)}
    
    def handle_company_registration(self, context):
        """Guide through SA company registration"""
        company_name = context.get("company_name", "")
        
        return {
            "type": "company_registration",
            "steps": [
                "1. Reserve company name with CIPC",
                "2. Prepare founding documents (MOI)",
                "3. Register with CIPC online",
                "4. Obtain tax number from SARS",
                "5. Register for VAT (if applicable)",
                "6. Register for PAYE",
                "7. Open business bank account",
                "8. Register with UIF"
            ],
            "estimated_time": "5-10 business days",
            "costs": {
                "cipc_registration": "R125-R475",
                "name_reservation": "R50",
                "total_estimated": "R200-R600"
            },
            "links": {
                "cipc": "https://eservices.cipc.co.za",
                "sars": "https://www.sars.gov.za"
            }
        }


class LegalDepartment:
    """
    Complete Legal Department with full hierarchy
    """
    
    def __init__(self):
        self.clo = CLOAgent()
        self.lawyer = CorporateLawyer(self.clo)
        self.compliance = ComplianceOfficer(self.lawyer)
        
    def get_department_status(self):
        """Get status of entire legal department"""
        return {
            "department": "Legal",
            "hierarchy": {
                "clo": self.clo.get_status(),
                "corporate_lawyer": self.lawyer.get_status(),
                "compliance_officer": self.compliance.get_status()
            },
            "total_agents": 3
        }
    
    def delegate_task(self, task, context=None):
        """Intelligently delegate task to appropriate team member"""
        task_lower = task.lower()
        
        if any(word in task_lower for word in ["strategy", "major", "risk assessment"]):
            return self.clo.execute_task(task, context)
        elif any(word in task_lower for word in ["contract", "draft", "nda", "agreement"]):
            return self.lawyer.execute_task(task, context)
        elif any(word in task_lower for word in ["compliance", "popia", "register", "audit"]):
            return self.compliance.execute_task(task, context)
        else:
            return self.clo.execute_task(task, context)
