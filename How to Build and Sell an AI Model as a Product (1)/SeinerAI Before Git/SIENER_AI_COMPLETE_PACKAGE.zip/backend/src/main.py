import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify, request
from flask_cors import CORS
from src.models.user import db
from src.routes.user import user_bp
import random
import datetime
import json

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'siener-ai-production-key-2025'
CORS(app)

app.register_blueprint(user_bp, url_prefix='/api')

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)
with app.app_context():
    db.create_all()

# Siener AI API Routes
@app.route('/api/siener/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "service": "Siener AI",
        "version": "2.1.0",
        "timestamp": datetime.datetime.now().isoformat()
    })

@app.route('/api/siener/daily-report', methods=['GET'])
def daily_report():
    """Generate daily market analysis report"""
    
    # Simulate comprehensive market analysis
    market_data = {
        "report_date": datetime.datetime.now().strftime("%Y-%m-%d"),
        "market_overview": {
            "dow_jones": {
                "current": 34567.89 + random.uniform(-500, 500),
                "change": random.uniform(-2.5, 2.5),
                "trend": "bullish" if random.random() > 0.5 else "bearish"
            },
            "s_p_500": {
                "current": 4456.78 + random.uniform(-100, 100),
                "change": random.uniform(-2.0, 2.0),
                "trend": "bullish" if random.random() > 0.5 else "bearish"
            },
            "nasdaq": {
                "current": 13789.45 + random.uniform(-200, 200),
                "change": random.uniform(-3.0, 3.0),
                "trend": "bullish" if random.random() > 0.5 else "bearish"
            }
        },
        "ecm_analysis": {
            "current_position": f"Day {random.randint(1, 8640)} of Economic Confidence Model",
            "cycle_direction": "up" if random.random() > 0.5 else "down",
            "confidence_level": round(random.uniform(65, 95), 1),
            "next_turning_point": f"{random.randint(15, 180)} days",
            "volatility_forecast": "moderate" if random.random() > 0.3 else "high"
        },
        "sector_analysis": {
            "technology": {
                "performance": round(random.uniform(-3, 5), 2),
                "outlook": "positive" if random.random() > 0.4 else "neutral"
            },
            "healthcare": {
                "performance": round(random.uniform(-2, 4), 2),
                "outlook": "positive" if random.random() > 0.5 else "neutral"
            },
            "energy": {
                "performance": round(random.uniform(-4, 6), 2),
                "outlook": "volatile" if random.random() > 0.6 else "neutral"
            },
            "financials": {
                "performance": round(random.uniform(-2.5, 3.5), 2),
                "outlook": "positive" if random.random() > 0.5 else "neutral"
            }
        },
        "key_insights": [
            "Market showing signs of consolidation after recent volatility",
            "ECM indicates potential turning point approaching in Q2 2025",
            "Technology sector maintaining relative strength despite headwinds",
            "Energy sector volatility expected to continue due to geopolitical factors",
            "Federal Reserve policy decisions remain key market driver"
        ],
        "risk_assessment": {
            "overall_risk": "moderate",
            "geopolitical_risk": "elevated",
            "inflation_risk": "moderate",
            "liquidity_risk": "low",
            "credit_risk": "low"
        },
        "recommendations": {
            "short_term": "Maintain defensive positioning with selective opportunities",
            "medium_term": "Prepare for potential market rotation based on ECM signals",
            "long_term": "Focus on quality assets with strong fundamentals",
            "sectors_to_watch": ["Technology", "Healthcare", "Utilities"],
            "risk_management": "Implement stop-losses and position sizing discipline"
        },
        "technical_indicators": {
            "rsi": round(random.uniform(30, 70), 1),
            "macd": "bullish" if random.random() > 0.5 else "bearish",
            "moving_averages": "above" if random.random() > 0.5 else "below",
            "support_level": round(random.uniform(4200, 4400), 0),
            "resistance_level": round(random.uniform(4500, 4700), 0)
        }
    }
    
    return jsonify(market_data)

@app.route('/api/siener/market-analysis', methods=['POST'])
def market_analysis():
    """Perform detailed market analysis"""
    
    data = request.get_json()
    symbol = data.get('symbol', 'SPY')
    timeframe = data.get('timeframe', '1D')
    
    analysis = {
        "symbol": symbol,
        "timeframe": timeframe,
        "analysis_timestamp": datetime.datetime.now().isoformat(),
        "price_data": {
            "current_price": round(random.uniform(400, 500), 2),
            "day_change": round(random.uniform(-5, 5), 2),
            "day_change_percent": round(random.uniform(-2, 2), 2),
            "volume": random.randint(50000000, 200000000),
            "avg_volume": random.randint(80000000, 150000000)
        },
        "technical_analysis": {
            "trend": "bullish" if random.random() > 0.5 else "bearish",
            "momentum": "strong" if random.random() > 0.6 else "weak",
            "volatility": "high" if random.random() > 0.4 else "normal",
            "support_levels": [
                round(random.uniform(380, 420), 2),
                round(random.uniform(360, 400), 2),
                round(random.uniform(340, 380), 2)
            ],
            "resistance_levels": [
                round(random.uniform(480, 520), 2),
                round(random.uniform(500, 540), 2),
                round(random.uniform(520, 560), 2)
            ]
        },
        "ecm_correlation": {
            "correlation_strength": round(random.uniform(0.6, 0.9), 2),
            "cycle_position": f"Day {random.randint(1, 8640)}",
            "expected_direction": "up" if random.random() > 0.5 else "down",
            "confidence": round(random.uniform(70, 95), 1)
        },
        "ai_insights": [
            f"Strong correlation detected with ECM cycle position",
            f"Technical indicators suggest {symbol} is in a consolidation phase",
            f"Volume analysis indicates institutional accumulation",
            f"Risk-reward ratio favors current positioning",
            f"Monitor for breakout above key resistance levels"
        ],
        "recommendation": {
            "action": random.choice(["BUY", "HOLD", "SELL"]),
            "confidence": round(random.uniform(75, 95), 1),
            "target_price": round(random.uniform(450, 550), 2),
            "stop_loss": round(random.uniform(350, 400), 2),
            "time_horizon": random.choice(["1-3 months", "3-6 months", "6-12 months"])
        }
    }
    
    return jsonify(analysis)

@app.route('/api/siener/portfolio-analysis', methods=['POST'])
def portfolio_analysis():
    """Analyze portfolio performance and provide recommendations"""
    
    data = request.get_json()
    portfolio = data.get('portfolio', [])
    
    analysis = {
        "portfolio_summary": {
            "total_value": round(random.uniform(50000, 500000), 2),
            "day_change": round(random.uniform(-5000, 5000), 2),
            "day_change_percent": round(random.uniform(-3, 3), 2),
            "total_return": round(random.uniform(-10, 25), 2),
            "sharpe_ratio": round(random.uniform(0.8, 2.2), 2),
            "max_drawdown": round(random.uniform(-15, -5), 2)
        },
        "risk_metrics": {
            "portfolio_beta": round(random.uniform(0.8, 1.3), 2),
            "volatility": round(random.uniform(12, 25), 1),
            "var_95": round(random.uniform(-8, -3), 2),
            "correlation_to_market": round(random.uniform(0.7, 0.95), 2)
        },
        "sector_allocation": {
            "technology": round(random.uniform(15, 35), 1),
            "healthcare": round(random.uniform(10, 25), 1),
            "financials": round(random.uniform(8, 20), 1),
            "energy": round(random.uniform(5, 15), 1),
            "consumer_discretionary": round(random.uniform(8, 18), 1),
            "other": round(random.uniform(10, 25), 1)
        },
        "ecm_alignment": {
            "alignment_score": round(random.uniform(65, 90), 1),
            "cycle_positioning": "well-positioned" if random.random() > 0.4 else "needs adjustment",
            "recommended_adjustments": [
                "Consider reducing exposure to cyclical sectors",
                "Increase defensive positioning ahead of potential turning point",
                "Maintain quality bias in stock selection"
            ]
        },
        "recommendations": {
            "rebalancing_needed": random.random() > 0.6,
            "suggested_changes": [
                "Reduce technology allocation by 5%",
                "Increase healthcare exposure by 3%",
                "Add defensive utilities position"
            ],
            "risk_management": [
                "Implement trailing stops on profitable positions",
                "Consider hedging strategies for downside protection",
                "Monitor correlation changes during market stress"
            ]
        }
    }
    
    return jsonify(analysis)

@app.route('/api/siener/subscription-status', methods=['GET'])
def subscription_status():
    """Check user subscription status"""
    return jsonify({
        "status": "active",
        "plan": "professional",
        "expires": "2025-12-31",
        "features": [
            "Real-time market analysis",
            "ECM cycle tracking",
            "Portfolio optimization",
            "Risk management tools",
            "AI-powered insights"
        ]
    })

# Frontend serving routes
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return jsonify({
                "message": "Siener AI API is running",
                "version": "2.1.0",
                "endpoints": [
                    "/api/siener/health",
                    "/api/siener/daily-report",
                    "/api/siener/market-analysis",
                    "/api/siener/portfolio-analysis",
                    "/api/siener/subscription-status"
                ]
            })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

