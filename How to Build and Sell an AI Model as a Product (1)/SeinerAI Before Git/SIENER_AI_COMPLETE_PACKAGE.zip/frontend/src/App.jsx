import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert.jsx'
import { 
  Eye, 
  TrendingUp, 
  BarChart3, 
  Globe, 
  Zap, 
  Shield,
  RefreshCw,
  Activity,
  AlertTriangle,
  CheckCircle,
  Clock,
  DollarSign,
  Users,
  Target,
  Brain,
  Sparkles
} from 'lucide-react'
import './App.css'

function App() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [marketData, setMarketData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [lastUpdate, setLastUpdate] = useState(new Date())

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdate(new Date())
    }, 30000) // Update every 30 seconds

    return () => clearInterval(interval)
  }, [])

  const fetchMarketData = async () => {
    setLoading(true)
    try {
      // Simulate API call - in production this would call your Flask backend
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      const mockData = {
        ecm_position: `Day ${Math.floor(Math.random() * 8640) + 1} of Economic Confidence Model`,
        confidence_level: Math.floor(Math.random() * 30) + 70,
        market_direction: Math.random() > 0.5 ? 'Bullish' : 'Bearish',
        volatility: Math.random() > 0.6 ? 'High' : 'Moderate',
        next_turning_point: `${Math.floor(Math.random() * 180) + 15} days`,
        key_levels: {
          support: Math.floor(Math.random() * 200) + 4200,
          resistance: Math.floor(Math.random() * 200) + 4500
        },
        sectors: {
          technology: { performance: (Math.random() * 6 - 3).toFixed(2), outlook: 'Positive' },
          healthcare: { performance: (Math.random() * 4 - 2).toFixed(2), outlook: 'Neutral' },
          energy: { performance: (Math.random() * 8 - 4).toFixed(2), outlook: 'Volatile' },
          financials: { performance: (Math.random() * 5 - 2.5).toFixed(2), outlook: 'Positive' }
        },
        predictions: [
          "ECM indicates potential market turning point approaching in Q2 2025",
          "Technology sector showing relative strength despite headwinds",
          "Energy volatility expected to continue due to geopolitical factors",
          "Defensive positioning recommended for next 30-60 days"
        ]
      }
      
      setMarketData(mockData)
    } catch (error) {
      console.error('Failed to fetch market data:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchMarketData()
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <Eye className="h-8 w-8 text-blue-600" />
                  <Sparkles className="h-4 w-4 text-yellow-500 absolute -top-1 -right-1" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Siener AI</h1>
                  <p className="text-sm text-gray-600">Advanced Market Analysis System</p>
                </div>
              </div>
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                <Activity className="h-3 w-3 mr-1" />
                Live
              </Badge>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                variant="outline" 
                size="sm"
                onClick={fetchMarketData}
                disabled={loading}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <Badge variant="secondary" className="text-xs">
                Last updated: {lastUpdate.toLocaleTimeString()}
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-4">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="market-analysis">Market Analysis</TabsTrigger>
            <TabsTrigger value="global-markets">Global Markets</TabsTrigger>
            <TabsTrigger value="cycle-analysis">Cycle Analysis</TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            {loading && (
              <Alert>
                <RefreshCw className="h-4 w-4 animate-spin" />
                <AlertTitle>Updating Market Data</AlertTitle>
                <AlertDescription>
                  Fetching the latest market analysis from Siener AI...
                </AlertDescription>
              </Alert>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">ECM Confidence</CardTitle>
                  <Brain className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">
                    {marketData?.confidence_level || 85}%
                  </div>
                  <Progress value={marketData?.confidence_level || 85} className="mt-2" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Market Direction</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className={`text-2xl font-bold ${
                    marketData?.market_direction === 'Bullish' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {marketData?.market_direction || 'Bullish'}
                  </div>
                  <p className="text-xs text-muted-foreground">Based on ECM analysis</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Volatility</CardTitle>
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className={`text-2xl font-bold ${
                    marketData?.volatility === 'High' ? 'text-orange-600' : 'text-blue-600'
                  }`}>
                    {marketData?.volatility || 'Moderate'}
                  </div>
                  <p className="text-xs text-muted-foreground">Current market conditions</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Next Turning Point</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-purple-600">
                    {marketData?.next_turning_point || '45 days'}
                  </div>
                  <p className="text-xs text-muted-foreground">ECM projection</p>
                </CardContent>
              </Card>
            </div>

            {/* ECM Position */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Eye className="h-5 w-5 text-blue-600" />
                  <span>Economic Confidence Model Position</span>
                </CardTitle>
                <CardDescription>Current position in the 8.6-year economic cycle</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-lg font-semibold text-gray-900 mb-4">
                  {marketData?.ecm_position || 'Day 3,247 of Economic Confidence Model'}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Key Support & Resistance</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Support:</span>
                        <span className="text-sm font-medium text-green-600">
                          {marketData?.key_levels?.support || 4,285}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Resistance:</span>
                        <span className="text-sm font-medium text-red-600">
                          {marketData?.key_levels?.resistance || 4,567}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Cycle Analysis</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Phase:</span>
                        <span className="text-sm font-medium">Consolidation</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Trend:</span>
                        <span className="text-sm font-medium text-blue-600">Sideways</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Sector Performance */}
            <Card>
              <CardHeader>
                <CardTitle>Sector Performance</CardTitle>
                <CardDescription>Real-time sector analysis and outlook</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {marketData?.sectors && Object.entries(marketData.sectors).map(([sector, data]) => (
                    <div key={sector} className="p-4 border rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="font-medium capitalize">{sector}</h4>
                        <Badge variant={data.outlook === 'Positive' ? 'default' : 
                                     data.outlook === 'Volatile' ? 'destructive' : 'secondary'}>
                          {data.outlook}
                        </Badge>
                      </div>
                      <div className={`text-lg font-bold ${
                        parseFloat(data.performance) > 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {data.performance > 0 ? '+' : ''}{data.performance}%
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* AI Predictions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Sparkles className="h-5 w-5 text-yellow-500" />
                  <span>Siener AI Predictions</span>
                </CardTitle>
                <CardDescription>AI-powered market insights and forecasts</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {marketData?.predictions?.map((prediction, index) => (
                    <div key={index} className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
                      <Brain className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-gray-700">{prediction}</p>
                    </div>
                  )) || [
                    "ECM indicates potential market turning point approaching in Q2 2025",
                    "Technology sector showing relative strength despite headwinds",
                    "Energy volatility expected to continue due to geopolitical factors",
                    "Defensive positioning recommended for next 30-60 days"
                  ].map((prediction, index) => (
                    <div key={index} className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
                      <Brain className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-gray-700">{prediction}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Market Analysis Tab */}
          <TabsContent value="market-analysis" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Advanced Market Analysis</CardTitle>
                <CardDescription>Deep dive into market conditions using Siener AI</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-medium">Technical Indicators</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">RSI (14)</span>
                        <Badge variant="outline">67.3</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">MACD</span>
                        <Badge variant="default">Bullish</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Moving Averages</span>
                        <Badge variant="default">Above</Badge>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h4 className="font-medium">Risk Assessment</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Overall Risk</span>
                        <Badge variant="secondary">Moderate</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Geopolitical Risk</span>
                        <Badge variant="destructive">Elevated</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Liquidity Risk</span>
                        <Badge variant="default">Low</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Market Recommendations</CardTitle>
                <CardDescription>Strategic guidance based on current analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Alert>
                    <CheckCircle className="h-4 w-4" />
                    <AlertTitle>Short-term Strategy</AlertTitle>
                    <AlertDescription>
                      Maintain defensive positioning with selective opportunities in quality names.
                    </AlertDescription>
                  </Alert>
                  <Alert>
                    <Clock className="h-4 w-4" />
                    <AlertTitle>Medium-term Outlook</AlertTitle>
                    <AlertDescription>
                      Prepare for potential market rotation based on ECM signals approaching.
                    </AlertDescription>
                  </Alert>
                  <Alert>
                    <Target className="h-4 w-4" />
                    <AlertTitle>Long-term View</AlertTitle>
                    <AlertDescription>
                      Focus on quality assets with strong fundamentals and pricing power.
                    </AlertDescription>
                  </Alert>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Global Markets Tab */}
          <TabsContent value="global-markets" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">US Markets</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">S&P 500</span>
                      <span className="text-sm font-medium text-green-600">+0.8%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">NASDAQ</span>
                      <span className="text-sm font-medium text-green-600">+1.2%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Dow Jones</span>
                      <span className="text-sm font-medium text-red-600">-0.3%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">European Markets</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">FTSE 100</span>
                      <span className="text-sm font-medium text-green-600">+0.5%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">DAX</span>
                      <span className="text-sm font-medium text-green-600">+0.7%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">CAC 40</span>
                      <span className="text-sm font-medium text-red-600">-0.2%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Asian Markets</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">Nikkei 225</span>
                      <span className="text-sm font-medium text-green-600">+1.1%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Hang Seng</span>
                      <span className="text-sm font-medium text-red-600">-0.8%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Shanghai</span>
                      <span className="text-sm font-medium text-green-600">+0.4%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Currency & Commodities</CardTitle>
                <CardDescription>Global currency and commodity movements</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium mb-3">Major Currencies</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">EUR/USD</span>
                        <span className="text-sm font-medium">1.0875</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">GBP/USD</span>
                        <span className="text-sm font-medium">1.2634</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">USD/JPY</span>
                        <span className="text-sm font-medium">149.82</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-3">Commodities</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Gold</span>
                        <span className="text-sm font-medium text-green-600">$2,045</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Oil (WTI)</span>
                        <span className="text-sm font-medium text-red-600">$78.45</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Silver</span>
                        <span className="text-sm font-medium text-green-600">$24.67</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Cycle Analysis Tab */}
          <TabsContent value="cycle-analysis" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Eye className="h-5 w-5 text-blue-600" />
                  <span>Economic Confidence Model Deep Dive</span>
                </CardTitle>
                <CardDescription>
                  Advanced analysis of the 8.6-year economic cycle and its implications
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium mb-3">Cycle Characteristics</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-sm">Total Cycle Length</span>
                          <span className="text-sm font-medium">8.6 years (3,141 days)</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">Current Position</span>
                          <span className="text-sm font-medium text-blue-600">
                            Day {Math.floor(Math.random() * 3141) + 1}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">Phase</span>
                          <span className="text-sm font-medium">Consolidation</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">Next Major Turn</span>
                          <span className="text-sm font-medium text-purple-600">Q2 2025</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium mb-3">Historical Context</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-sm">Last Major High</span>
                          <span className="text-sm font-medium">2021.75</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">Last Major Low</span>
                          <span className="text-sm font-medium">2020.05</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">Cycle Reliability</span>
                          <span className="text-sm font-medium text-green-600">94.7%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm">Prediction Accuracy</span>
                          <span className="text-sm font-medium text-green-600">89.3%</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <Alert>
                    <Brain className="h-4 w-4" />
                    <AlertTitle>Siener AI Analysis</AlertTitle>
                    <AlertDescription>
                      Based on the current ECM position, we are approaching a critical juncture in the cycle. 
                      Historical patterns suggest increased volatility in the coming months, followed by a 
                      potential directional move that could last 12-18 months.
                    </AlertDescription>
                  </Alert>

                  <div>
                    <h4 className="font-medium mb-3">Key Turning Points Ahead</h4>
                    <div className="space-y-3">
                      <div className="p-3 border rounded-lg">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-sm font-medium">Minor Turn</span>
                          <Badge variant="outline">15-30 days</Badge>
                        </div>
                        <p className="text-xs text-gray-600">
                          Short-term directional change expected, likely lasting 2-4 weeks
                        </p>
                      </div>
                      <div className="p-3 border rounded-lg">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-sm font-medium">Intermediate Turn</span>
                          <Badge variant="outline">45-75 days</Badge>
                        </div>
                        <p className="text-xs text-gray-600">
                          Medium-term cycle completion, potential for 3-6 month trend
                        </p>
                      </div>
                      <div className="p-3 border rounded-lg">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-sm font-medium">Major Turn</span>
                          <Badge variant="outline">120-180 days</Badge>
                        </div>
                        <p className="text-xs text-gray-600">
                          Significant cycle inflection point, could drive 12-24 month trend
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default App

