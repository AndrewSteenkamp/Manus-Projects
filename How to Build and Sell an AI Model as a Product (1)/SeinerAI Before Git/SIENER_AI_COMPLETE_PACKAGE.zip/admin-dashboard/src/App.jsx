import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert.jsx'
import { 
  Activity, 
  Users, 
  Code, 
  Package, 
  Settings, 
  Shield, 
  Database, 
  Monitor,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
  Server,
  Cpu,
  HardDrive,
  Network,
  DollarSign,
  Target,
  BarChart3,
  GitBranch,
  Zap,
  Bell,
  Calendar,
  FileText,
  MessageSquare,
  Briefcase
} from 'lucide-react'
import './App.css'

function App() {
  const [activeModule, setActiveModule] = useState('overview')
  const [systemHealth, setSystemHealth] = useState(95.8)
  const [notifications, setNotifications] = useState([])
  const [moduleData, setModuleData] = useState({})

  // Simulate real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setSystemHealth(prev => Math.max(90, Math.min(100, prev + (Math.random() - 0.5) * 2)))
      
      // Simulate module updates
      setModuleData({
        engineering: {
          activeProjects: 8,
          completedTasks: 156,
          codeQuality: 94.2,
          deploymentSuccess: 98.5,
          teamUtilization: 78.3
        },
        product: {
          activeInitiatives: 5,
          featuresInBacklog: 23,
          userSatisfaction: 4.6,
          adoptionRate: 82.1,
          marketPenetration: 15.7
        },
        design: {
          activeDesigns: 12,
          completedProjects: 34,
          designSystemUsage: 89.4,
          userTestingScore: 9.2,
          accessibilityCompliance: 96.8
        },
        marketing: {
          activeCampaigns: 7,
          leadGeneration: 1250,
          conversionRate: 12.8,
          brandAwareness: 67.3,
          socialEngagement: 145.6
        },
        projectManagement: {
          activeProjects: 12,
          onTimeDelivery: 94.5,
          budgetAdherence: 97.2,
          stakeholderSatisfaction: 9.1,
          resourceUtilization: 82.7
        },
        studioOperations: {
          systemUptime: 99.95,
          responseTime: 145,
          errorRate: 0.02,
          securityScore: 96.8,
          costOptimization: 23.7
        }
      })
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const modules = [
    {
      id: 'engineering',
      name: 'Engineering',
      icon: Code,
      status: 'operational',
      health: 96.2,
      description: '8 specialists managing technical development',
      metrics: {
        'Active Projects': moduleData.engineering?.activeProjects || 8,
        'Code Quality': `${moduleData.engineering?.codeQuality || 94.2}%`,
        'Deployment Success': `${moduleData.engineering?.deploymentSuccess || 98.5}%`,
        'Team Utilization': `${moduleData.engineering?.teamUtilization || 78.3}%`
      }
    },
    {
      id: 'product',
      name: 'Product',
      icon: Package,
      status: 'operational',
      health: 93.7,
      description: '8 specialists managing product lifecycle',
      metrics: {
        'Active Initiatives': moduleData.product?.activeInitiatives || 5,
        'User Satisfaction': `${moduleData.product?.userSatisfaction || 4.6}/5`,
        'Adoption Rate': `${moduleData.product?.adoptionRate || 82.1}%`,
        'Market Penetration': `${moduleData.product?.marketPenetration || 15.7}%`
      }
    },
    {
      id: 'design',
      name: 'Design',
      icon: Briefcase,
      status: 'operational',
      health: 97.1,
      description: '2 specialists managing UI/UX design',
      metrics: {
        'Active Designs': moduleData.design?.activeDesigns || 12,
        'Design System Usage': `${moduleData.design?.designSystemUsage || 89.4}%`,
        'User Testing Score': `${moduleData.design?.userTestingScore || 9.2}/10`,
        'Accessibility': `${moduleData.design?.accessibilityCompliance || 96.8}%`
      }
    },
    {
      id: 'marketing',
      name: 'Marketing',
      icon: TrendingUp,
      status: 'operational',
      health: 91.4,
      description: '7 specialists managing marketing campaigns',
      metrics: {
        'Active Campaigns': moduleData.marketing?.activeCampaigns || 7,
        'Lead Generation': moduleData.marketing?.leadGeneration || 1250,
        'Conversion Rate': `${moduleData.marketing?.conversionRate || 12.8}%`,
        'Social Engagement': `${moduleData.marketing?.socialEngagement || 145.6}%`
      }
    },
    {
      id: 'projectManagement',
      name: 'Project Management',
      icon: Calendar,
      status: 'operational',
      health: 94.8,
      description: '8 specialists managing project execution',
      metrics: {
        'Active Projects': moduleData.projectManagement?.activeProjects || 12,
        'On-Time Delivery': `${moduleData.projectManagement?.onTimeDelivery || 94.5}%`,
        'Budget Adherence': `${moduleData.projectManagement?.budgetAdherence || 97.2}%`,
        'Stakeholder Satisfaction': `${moduleData.projectManagement?.stakeholderSatisfaction || 9.1}/10`
      }
    },
    {
      id: 'studioOperations',
      name: 'Studio Operations',
      icon: Server,
      status: 'operational',
      health: 98.3,
      description: '8 specialists managing infrastructure & operations',
      metrics: {
        'System Uptime': `${moduleData.studioOperations?.systemUptime || 99.95}%`,
        'Response Time': `${moduleData.studioOperations?.responseTime || 145}ms`,
        'Error Rate': `${moduleData.studioOperations?.errorRate || 0.02}%`,
        'Security Score': `${moduleData.studioOperations?.securityScore || 96.8}%`
      }
    }
  ]

  const getStatusColor = (status) => {
    switch (status) {
      case 'operational': return 'bg-green-500'
      case 'warning': return 'bg-yellow-500'
      case 'critical': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const getHealthColor = (health) => {
    if (health >= 95) return 'text-green-600'
    if (health >= 85) return 'text-yellow-600'
    return 'text-red-600'
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Activity className="h-8 w-8 text-blue-600" />
                <h1 className="text-2xl font-bold text-gray-900">Socrates AI Admin Dashboard</h1>
              </div>
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                System Health: {systemHealth.toFixed(1)}%
              </Badge>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4 mr-2" />
                Notifications
              </Button>
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeModule} onValueChange={setActiveModule} className="space-y-6">
          <TabsList className="grid w-full grid-cols-7 lg:w-auto lg:grid-cols-7">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="engineering">Engineering</TabsTrigger>
            <TabsTrigger value="product">Product</TabsTrigger>
            <TabsTrigger value="design">Design</TabsTrigger>
            <TabsTrigger value="marketing">Marketing</TabsTrigger>
            <TabsTrigger value="projectManagement">PM</TabsTrigger>
            <TabsTrigger value="studioOperations">Operations</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">System Health</CardTitle>
                  <Activity className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{systemHealth.toFixed(1)}%</div>
                  <Progress value={systemHealth} className="mt-2" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Modules</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">6</div>
                  <p className="text-xs text-muted-foreground">All operational</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Team Members</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">41</div>
                  <p className="text-xs text-muted-foreground">Across all modules</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Projects</CardTitle>
                  <Briefcase className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">45</div>
                  <p className="text-xs text-muted-foreground">In progress</p>
                </CardContent>
              </Card>
            </div>

            {/* Module Status Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {modules.map((module) => {
                const IconComponent = module.icon
                return (
                  <Card key={module.id} className="hover:shadow-lg transition-shadow cursor-pointer"
                        onClick={() => setActiveModule(module.id)}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <IconComponent className="h-6 w-6 text-blue-600" />
                          <CardTitle className="text-lg">{module.name}</CardTitle>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className={`w-3 h-3 rounded-full ${getStatusColor(module.status)}`}></div>
                          <span className={`text-sm font-semibold ${getHealthColor(module.health)}`}>
                            {module.health}%
                          </span>
                        </div>
                      </div>
                      <CardDescription>{module.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        {Object.entries(module.metrics).map(([key, value]) => (
                          <div key={key}>
                            <p className="text-muted-foreground">{key}</p>
                            <p className="font-semibold">{value}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Latest updates from all modules</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Engineering: Deployed Socrates AI v2.1.0</p>
                      <p className="text-xs text-muted-foreground">2 minutes ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Product: New feature "AI Recommendations" approved</p>
                      <p className="text-xs text-muted-foreground">15 minutes ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Design: Mobile UI redesign completed</p>
                      <p className="text-xs text-muted-foreground">1 hour ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Marketing: Q1 campaign achieved 125% of target</p>
                      <p className="text-xs text-muted-foreground">3 hours ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Engineering Module Tab */}
          <TabsContent value="engineering" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Projects</CardTitle>
                  <GitBranch className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{moduleData.engineering?.activeProjects || 8}</div>
                  <p className="text-xs text-muted-foreground">2 critical, 6 normal</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Code Quality</CardTitle>
                  <CheckCircle className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{moduleData.engineering?.codeQuality || 94.2}%</div>
                  <Progress value={moduleData.engineering?.codeQuality || 94.2} className="mt-2" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Deployment Success</CardTitle>
                  <Zap className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{moduleData.engineering?.deploymentSuccess || 98.5}%</div>
                  <p className="text-xs text-muted-foreground">15 deployments this week</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Team Utilization</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{moduleData.engineering?.teamUtilization || 78.3}%</div>
                  <Progress value={moduleData.engineering?.teamUtilization || 78.3} className="mt-2" />
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Engineering Team</CardTitle>
                  <CardDescription>8 world-class specialists</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { name: 'Backend Architect', workload: 85, status: 'active' },
                      { name: 'Frontend Specialist', workload: 72, status: 'active' },
                      { name: 'DevOps Engineer', workload: 90, status: 'active' },
                      { name: 'Full-Stack Developer', workload: 68, status: 'active' },
                      { name: 'AI/ML Engineer', workload: 95, status: 'active' },
                      { name: 'QA Automation Engineer', workload: 75, status: 'active' },
                      { name: 'Mobile Developer', workload: 60, status: 'active' },
                      { name: 'Security Engineer', workload: 80, status: 'active' }
                    ].map((member, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-sm font-medium">{member.name}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Progress value={member.workload} className="w-20" />
                          <span className="text-xs text-muted-foreground w-8">{member.workload}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Current Sprint</CardTitle>
                  <CardDescription>Sprint 23 - Socrates AI Platform</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Sprint Progress</span>
                      <span className="text-sm font-semibold">Day 8 of 14</span>
                    </div>
                    <Progress value={57} className="w-full" />
                    
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <p className="text-2xl font-bold text-green-600">12</p>
                        <p className="text-xs text-muted-foreground">Completed</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-blue-600">8</p>
                        <p className="text-xs text-muted-foreground">In Progress</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-gray-600">5</p>
                        <p className="text-xs text-muted-foreground">Remaining</p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Real-time Analytics Engine</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">Done</Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>AI Recommendation System</span>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700">In Progress</Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>Mobile App Integration</span>
                        <Badge variant="outline" className="bg-yellow-50 text-yellow-700">Review</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Product Module Tab */}
          <TabsContent value="product" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Initiatives</CardTitle>
                  <Target className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{moduleData.product?.activeInitiatives || 5}</div>
                  <p className="text-xs text-muted-foreground">2 in discovery phase</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">User Satisfaction</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{moduleData.product?.userSatisfaction || 4.6}/5</div>
                  <p className="text-xs text-muted-foreground">Based on 2,500 reviews</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Feature Adoption</CardTitle>
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{moduleData.product?.adoptionRate || 82.1}%</div>
                  <Progress value={moduleData.product?.adoptionRate || 82.1} className="mt-2" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Market Penetration</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{moduleData.product?.marketPenetration || 15.7}%</div>
                  <p className="text-xs text-muted-foreground">+2.3% this quarter</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Product Roadmap</CardTitle>
                  <CardDescription>Q1 2025 Milestones</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <div className="flex-1">
                        <p className="text-sm font-medium">Real-time Dashboard Launch</p>
                        <p className="text-xs text-muted-foreground">Completed March 15</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Clock className="h-5 w-5 text-blue-500" />
                      <div className="flex-1">
                        <p className="text-sm font-medium">AI Recommendations Beta</p>
                        <p className="text-xs text-muted-foreground">In progress - Due March 30</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Clock className="h-5 w-5 text-gray-400" />
                      <div className="flex-1">
                        <p className="text-sm font-medium">Mobile App Release</p>
                        <p className="text-xs text-muted-foreground">Planned for April 15</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Clock className="h-5 w-5 text-gray-400" />
                      <div className="flex-1">
                        <p className="text-sm font-medium">Enterprise API Launch</p>
                        <p className="text-xs text-muted-foreground">Planned for May 1</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>User Feedback</CardTitle>
                  <CardDescription>Recent insights from user research</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Alert>
                      <TrendingUp className="h-4 w-4" />
                      <AlertTitle>Positive Trend</AlertTitle>
                      <AlertDescription>
                        95% of users find the new dashboard intuitive and easy to use.
                      </AlertDescription>
                    </Alert>
                    <Alert>
                      <AlertTriangle className="h-4 w-4" />
                      <AlertTitle>Improvement Opportunity</AlertTitle>
                      <AlertDescription>
                        Users requesting more customization options for alerts and notifications.
                      </AlertDescription>
                    </Alert>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">NPS Score</p>
                        <p className="text-2xl font-bold text-green-600">67</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">CSAT Score</p>
                        <p className="text-2xl font-bold text-green-600">4.6/5</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Design Module Tab */}
          <TabsContent value="design" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Designs</CardTitle>
                  <Briefcase className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{moduleData.design?.activeDesigns || 12}</div>
                  <p className="text-xs text-muted-foreground">3 in review phase</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Design System Usage</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{moduleData.design?.designSystemUsage || 89.4}%</div>
                  <Progress value={moduleData.design?.designSystemUsage || 89.4} className="mt-2" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">User Testing Score</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{moduleData.design?.userTestingScore || 9.2}/10</div>
                  <p className="text-xs text-muted-foreground">Based on 150 tests</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Accessibility</CardTitle>
                  <Shield className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{moduleData.design?.accessibilityCompliance || 96.8}%</div>
                  <p className="text-xs text-muted-foreground">WCAG AA compliant</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Design Team</CardTitle>
                  <CardDescription>2 world-class design specialists</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm font-medium">UI Designer Agent</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Progress value={82} className="w-20" />
                        <span className="text-xs text-muted-foreground w-8">82%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm font-medium">UX Designer Agent</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Progress value={75} className="w-20" />
                        <span className="text-xs text-muted-foreground w-8">75%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Design Updates</CardTitle>
                  <CardDescription>Latest design system improvements</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <div className="flex-1">
                        <p className="text-sm font-medium">Mobile Dashboard Redesign</p>
                        <p className="text-xs text-muted-foreground">Completed 2 hours ago</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <div className="flex-1">
                        <p className="text-sm font-medium">Color Palette Update</p>
                        <p className="text-xs text-muted-foreground">Completed yesterday</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <Clock className="h-5 w-5 text-blue-500" />
                      <div className="flex-1">
                        <p className="text-sm font-medium">Icon Library Expansion</p>
                        <p className="text-xs text-muted-foreground">In progress</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Studio Operations Tab */}
          <TabsContent value="studioOperations" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">System Uptime</CardTitle>
                  <Server className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{moduleData.studioOperations?.systemUptime || 99.95}%</div>
                  <p className="text-xs text-muted-foreground">30-day average</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Response Time</CardTitle>
                  <Zap className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{moduleData.studioOperations?.responseTime || 145}ms</div>
                  <p className="text-xs text-muted-foreground">Average API response</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Error Rate</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{moduleData.studioOperations?.errorRate || 0.02}%</div>
                  <p className="text-xs text-muted-foreground">Well below 0.1% target</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Security Score</CardTitle>
                  <Shield className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{moduleData.studioOperations?.securityScore || 96.8}%</div>
                  <Progress value={moduleData.studioOperations?.securityScore || 96.8} className="mt-2" />
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>System Resources</CardTitle>
                  <CardDescription>Current infrastructure utilization</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Cpu className="h-4 w-4 text-blue-500" />
                        <span className="text-sm">CPU Usage</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Progress value={45} className="w-20" />
                        <span className="text-xs text-muted-foreground w-8">45%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Database className="h-4 w-4 text-green-500" />
                        <span className="text-sm">Memory Usage</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Progress value={62} className="w-20" />
                        <span className="text-xs text-muted-foreground w-8">62%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <HardDrive className="h-4 w-4 text-purple-500" />
                        <span className="text-sm">Disk Usage</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Progress value={78} className="w-20" />
                        <span className="text-xs text-muted-foreground w-8">78%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Network className="h-4 w-4 text-orange-500" />
                        <span className="text-sm">Network I/O</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Progress value={34} className="w-20" />
                        <span className="text-xs text-muted-foreground w-8">34%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Operations Team</CardTitle>
                  <CardDescription>8 specialists managing infrastructure</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      { name: 'Site Reliability Engineer', status: 'on-call' },
                      { name: 'DevOps Engineer', status: 'active' },
                      { name: 'Infrastructure Engineer', status: 'active' },
                      { name: 'Security Engineer', status: 'on-call' },
                      { name: 'Database Administrator', status: 'active' },
                      { name: 'Monitoring Engineer', status: 'active' },
                      { name: 'Network Engineer', status: 'active' },
                      { name: 'Operations Manager', status: 'active' }
                    ].map((member, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm font-medium">{member.name}</span>
                        <Badge 
                          variant="outline" 
                          className={member.status === 'on-call' ? 'bg-orange-50 text-orange-700' : 'bg-green-50 text-green-700'}
                        >
                          {member.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Marketing Module Tab */}
          <TabsContent value="marketing" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Campaigns</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{moduleData.marketing?.activeCampaigns || 7}</div>
                  <p className="text-xs text-muted-foreground">3 social, 2 email, 2 paid</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Lead Generation</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{moduleData.marketing?.leadGeneration || 1250}</div>
                  <p className="text-xs text-muted-foreground">This month</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
                  <Target className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{moduleData.marketing?.conversionRate || 12.8}%</div>
                  <p className="text-xs text-muted-foreground">+2.1% from last month</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Social Engagement</CardTitle>
                  <MessageSquare className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{moduleData.marketing?.socialEngagement || 145.6}%</div>
                  <p className="text-xs text-muted-foreground">Above industry average</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Project Management Module Tab */}
          <TabsContent value="projectManagement" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Projects</CardTitle>
                  <Briefcase className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{moduleData.projectManagement?.activeProjects || 12}</div>
                  <p className="text-xs text-muted-foreground">2 critical, 10 normal</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">On-Time Delivery</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{moduleData.projectManagement?.onTimeDelivery || 94.5}%</div>
                  <Progress value={moduleData.projectManagement?.onTimeDelivery || 94.5} className="mt-2" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Budget Adherence</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{moduleData.projectManagement?.budgetAdherence || 97.2}%</div>
                  <p className="text-xs text-muted-foreground">Within budget targets</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Stakeholder Satisfaction</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{moduleData.projectManagement?.stakeholderSatisfaction || 9.1}/10</div>
                  <p className="text-xs text-muted-foreground">Excellent rating</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default App

