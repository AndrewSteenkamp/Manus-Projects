"""
Siener AI - Advanced Market Analysis System
A complete trading platform with AI-powered predictions
"""

from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
import requests
import json
import random
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Configuration
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'siener-ai-secret-key')

# Yoco Configuration
YOCO_SECRET_KEY = os.getenv('YOCO_SECRET_KEY')
YOCO_PUBLIC_KEY = os.getenv('YOCO_PUBLIC_KEY')

# Simple in-memory storage (replace with database in production)
users = {}
subscriptions = {}

# Import real market data module
from market_data import get_real_market_data, generate_real_ai_predictions

# Import Yoco payment integration
from yoco_payments import yoco_payments, subscription_manager

# Real market data (replaces simulation)
def get_market_data():
    """Get real market data from Yahoo Finance and ECM calculations"""
    return get_real_market_data()

def generate_ai_predictions():
    """Generate AI predictions based on real market conditions"""
    return generate_real_ai_predictions()

# Routes
@app.route('/')
def index():
    """Main dashboard"""
    return render_template_string("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Siener AI - Advanced Market Analysis</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            min-height: 100vh;
        }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .header { text-align: center; margin-bottom: 40px; }
        .header h1 { font-size: 2.5rem; margin-bottom: 10px; }
        .header p { font-size: 1.2rem; opacity: 0.9; }
        .dashboard { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .card { 
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 25px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .card h3 { margin-bottom: 15px; color: #ffd700; }
        .metric { display: flex; justify-content: space-between; margin: 10px 0; }
        .metric-value { font-weight: bold; color: #00ff88; }
        .predictions { margin-top: 20px; }
        .prediction { 
            background: rgba(255, 255, 255, 0.05);
            padding: 10px;
            margin: 10px 0;
            border-radius: 8px;
            border-left: 4px solid #ffd700;
        }
        .btn { 
            background: linear-gradient(45deg, #ffd700, #ffed4e);
            color: #1e3c72;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            margin: 10px 5px;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(255, 215, 0, 0.4); }
        .nav { display: flex; justify-content: center; margin-bottom: 30px; }
        .nav a { 
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 25px;
            background: rgba(255, 255, 255, 0.1);
        }
        .nav a:hover { background: rgba(255, 255, 255, 0.2); }
        .footer { text-align: center; margin-top: 40px; opacity: 0.7; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔮 Siener AI</h1>
            <p>Advanced Market Analysis System</p>
        </div>
        
        <div class="nav">
            <a href="/">Dashboard</a>
            <a href="/api/market-data">Market Data</a>
            <a href="/pricing">Pricing</a>
            <a href="/api/health">System Status</a>
        </div>

        <div class="dashboard" id="dashboard">
            <div class="card">
                <h3>📊 Market Overview</h3>
                <div class="metric">
                    <span>ECM Confidence:</span>
                    <span class="metric-value" id="ecm-confidence">Loading...</span>
                </div>
                <div class="metric">
                    <span>Market Direction:</span>
                    <span class="metric-value" id="market-direction">Loading...</span>
                </div>
                <div class="metric">
                    <span>Volatility:</span>
                    <span class="metric-value" id="volatility">Loading...</span>
                </div>
                <div class="metric">
                    <span>Next Turning Point:</span>
                    <span class="metric-value" id="turning-point">Loading...</span>
                </div>
            </div>

            <div class="card">
                <h3>🎯 Support & Resistance</h3>
                <div class="metric">
                    <span>Support Level:</span>
                    <span class="metric-value" id="support">Loading...</span>
                </div>
                <div class="metric">
                    <span>Resistance Level:</span>
                    <span class="metric-value" id="resistance">Loading...</span>
                </div>
            </div>

            <div class="card">
                <h3>🏭 Sector Performance</h3>
                <div id="sectors">Loading...</div>
            </div>

            <div class="card">
                <h3>🔮 AI Predictions</h3>
                <div class="predictions" id="predictions">Loading...</div>
            </div>
        </div>

        <div style="text-align: center; margin-top: 40px;">
            <a href="/pricing" class="btn">🚀 Upgrade to Pro</a>
            <a href="/api/market-data" class="btn">📈 View Full Data</a>
        </div>

        <div class="footer">
            <p>&copy; 2024 Siener AI - Powered by Advanced Market Intelligence</p>
        </div>
    </div>

    <script>
        // Load market data
        async function loadDashboard() {
            try {
                const response = await fetch('/api/market-data');
                const data = await response.json();
                
                // Update market overview
                document.getElementById('ecm-confidence').textContent = data.ecm_confidence + '%';
                document.getElementById('market-direction').textContent = data.market_direction;
                document.getElementById('volatility').textContent = data.volatility;
                document.getElementById('turning-point').textContent = data.next_turning_point + ' days';
                
                // Update support/resistance
                document.getElementById('support').textContent = data.support_level;
                document.getElementById('resistance').textContent = data.resistance_level;
                
                // Update sectors
                const sectorsDiv = document.getElementById('sectors');
                sectorsDiv.innerHTML = '';
                for (const [sector, info] of Object.entries(data.sectors)) {
                    sectorsDiv.innerHTML += `
                        <div class="metric">
                            <span>${sector}:</span>
                            <span class="metric-value">${info.performance} (${info.change})</span>
                        </div>
                    `;
                }
                
                // Load predictions
                const predictionsResponse = await fetch('/api/predictions');
                const predictions = await predictionsResponse.json();
                const predictionsDiv = document.getElementById('predictions');
                predictionsDiv.innerHTML = '';
                predictions.forEach(prediction => {
                    predictionsDiv.innerHTML += `<div class="prediction">${prediction}</div>`;
                });
                
            } catch (error) {
                console.error('Error loading dashboard:', error);
            }
        }
        
        // Load dashboard on page load
        loadDashboard();
        
        // Refresh every 30 seconds
        setInterval(loadDashboard, 30000);
    </script>
</body>
</html>
    """)

@app.route('/api/health')
def health_check():
    """API health check"""
    return jsonify({
        'status': 'healthy',
        'service': 'Siener AI',
        'version': '1.0.0',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/market-data')
def market_data():
    """Get current market data"""
    return jsonify(get_market_data())

@app.route('/api/predictions')
def predictions():
    """Get AI predictions"""
    return jsonify(generate_ai_predictions())

@app.route('/pricing')
def pricing():
    """Pricing page"""
    return render_template_string("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Siener AI - Pricing Plans</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            min-height: 100vh;
            padding: 20px;
        }
        .container { max-width: 1200px; margin: 0 auto; }
        .header { text-align: center; margin-bottom: 50px; }
        .header h1 { font-size: 2.5rem; margin-bottom: 10px; }
        .pricing-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; }
        .plan { 
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px;
            text-align: center;
            backdrop-filter: blur(10px);
            border: 2px solid rgba(255, 255, 255, 0.2);
            position: relative;
        }
        .plan.featured { 
            border-color: #ffd700;
            transform: scale(1.05);
        }
        .plan h3 { font-size: 1.8rem; margin-bottom: 10px; color: #ffd700; }
        .price { font-size: 3rem; font-weight: bold; margin: 20px 0; }
        .currency { font-size: 1.5rem; }
        .features { list-style: none; margin: 30px 0; }
        .features li { 
            padding: 10px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .features li:before { content: "✓ "; color: #00ff88; font-weight: bold; }
        .btn { 
            background: linear-gradient(45deg, #ffd700, #ffed4e);
            color: #1e3c72;
            padding: 15px 30px;
            border: none;
            border-radius: 10px;
            font-weight: bold;
            cursor: pointer;
            font-size: 1.1rem;
            width: 100%;
            margin-top: 20px;
        }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(255, 215, 0, 0.4); }
        .back-link { 
            display: inline-block;
            margin-bottom: 30px;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 25px;
        }
    </style>
    <script src="https://js.yoco.com/sdk/v1/yoco-sdk-web.js"></script>
</head>
<body>
    <div class="container">
        <a href="/" class="back-link">← Back to Dashboard</a>
        
        <div class="header">
            <h1>🔮 Choose Your Plan</h1>
            <p>Start your journey to smarter trading with Siener AI</p>
        </div>

        <div class="pricing-grid">
            <div class="plan">
                <h3>Basic</h3>
                <div class="price">R<span class="currency">499</span></div>
                <p>per month</p>
                <ul class="features">
                    <li>Daily market analysis</li>
                    <li>Basic AI predictions</li>
                    <li>JSE stock coverage</li>
                    <li>Email alerts</li>
                    <li>Mobile access</li>
                </ul>
                <button class="btn" onclick="subscribe('basic', 49900, 'Basic Plan')">Start Basic Plan</button>
            </div>

            <div class="plan featured">
                <h3>Professional</h3>
                <div class="price">R<span class="currency">999</span></div>
                <p>per month</p>
                <ul class="features">
                    <li>Everything in Basic</li>
                    <li>Advanced ECM analysis</li>
                    <li>Global market coverage</li>
                    <li>Real-time alerts</li>
                    <li>Portfolio tracking</li>
                    <li>Priority support</li>
                </ul>
                <button class="btn" onclick="subscribe('professional', 99900, 'Professional Plan')">Start Professional Plan</button>
            </div>

            <div class="plan">
                <h3>Enterprise</h3>
                <div class="price">R<span class="currency">2499</span></div>
                <p>per month</p>
                <ul class="features">
                    <li>Everything in Professional</li>
                    <li>Custom indicators</li>
                    <li>API access</li>
                    <li>White-label options</li>
                    <li>Dedicated support</li>
                    <li>Custom integrations</li>
                </ul>
                <button class="btn" onclick="subscribe('enterprise', 249900, 'Enterprise Plan')">Start Enterprise Plan</button>
            </div>
        </div>
    </div>

    <script>
        // Initialize Yoco (you'll need to add your public key)
        const YOCO_PUBLIC_KEY = "{{ yoco_public_key or 'pk_test_your_key_here' }}";
        
        function subscribe(planType, amountInCents, planName) {
            // For now, just show an alert - you'll integrate Yoco here
            alert(`Subscribing to ${planName} for R${amountInCents/100}. Yoco integration coming soon!`);
            
            // TODO: Implement Yoco payment flow
            /*
            const yoco = new YocoSDK({ publicKey: YOCO_PUBLIC_KEY });
            yoco.showPopup({
                amountInCents: amountInCents,
                currency: 'ZAR',
                name: 'Siener AI Subscription',
                description: planName,
                callback: function (result) {
                    if (result.error) {
                        alert("Payment failed: " + result.error.message);
                    } else {
                        // Send token to backend
                        fetch('/api/yoco/charge', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                token: result.id,
                                amount: amountInCents,
                                plan: planType
                            })
                        }).then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                alert("Subscription successful! Welcome to Siener AI.");
                                window.location.href = '/';
                            } else {
                                alert("Payment processing failed: " + data.message);
                            }
                        });
                    }
                }
            });
            */
        }
    </script>
</body>
</html>
    """)

@app.route('/api/yoco/charge', methods=['POST'])
def yoco_charge():
    """Handle Yoco payment charges"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['token', 'plan_type', 'user_email']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Process the payment
        result = yoco_payments.process_subscription_payment(
            plan_type=data['plan_type'],
            payment_token=data['token'],
            user_email=data['user_email'],
            user_name=data.get('user_name', 'Unknown')
        )
        
        if result['success']:
            # Store the subscription
            subscription_manager.create_subscription(result['subscription'])
            
            return jsonify({
                'success': True,
                'message': result['message'],
                'subscription': result['subscription']
            }), 200
        else:
            return jsonify({
                'success': False,
                'error': result['error']
            }), 400
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Payment processing error: {str(e)}'
        }), 500

@app.route('/api/subscription/status/<email>')
def get_subscription_status(email):
    """Get subscription status for a user"""
    try:
        subscription = subscription_manager.get_subscription(email)
        is_active = subscription_manager.is_subscription_active(email)
        plan_type = subscription_manager.get_user_plan(email)
        
        return jsonify({
            'has_subscription': subscription is not None,
            'is_active': is_active,
            'plan_type': plan_type,
            'subscription': subscription
        })
        
    except Exception as e:
        return jsonify({
            'error': f'Error checking subscription: {str(e)}'
        }), 500

@app.route('/api/plans')
def get_available_plans():
    """Get all available subscription plans"""
    try:
        plans = yoco_payments.get_all_plans()
        
        # Format plans for frontend
        formatted_plans = {}
        for plan_id, plan_data in plans.items():
            formatted_plans[plan_id] = {
                'id': plan_id,
                'name': plan_data['name'],
                'price': plan_data['price'] / 100,  # Convert to rands
                'price_display': f"R{plan_data['price'] / 100:.0f}",
                'currency': plan_data['currency'],
                'features': plan_data['features']
            }
        
        return jsonify({
            'success': True,
            'plans': formatted_plans
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Error fetching plans: {str(e)}'
        }), 500

@app.route('/api/yoco/public-key')
def get_yoco_public_key():
    """Get Yoco public key for frontend"""
    return jsonify({
        'public_key': yoco_payments.public_key
    })

if __name__ == '__main__':
    print("🔮 Starting Siener AI Server...")
    print("📊 Dashboard: http://localhost:5000")
    print("💰 Pricing: http://localhost:5000/pricing")
    print("🔧 API Health: http://localhost:5000/api/health")
    app.run(host='0.0.0.0', port=5000, debug=True)
