from flask import Flask; app = Flask(__name__); @app.route('/')\ndef index(): return 'Siener AI App Running'
