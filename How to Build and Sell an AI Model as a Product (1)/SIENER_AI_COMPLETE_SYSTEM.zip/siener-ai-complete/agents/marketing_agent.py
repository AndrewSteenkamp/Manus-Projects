print('Marketing Agent')
