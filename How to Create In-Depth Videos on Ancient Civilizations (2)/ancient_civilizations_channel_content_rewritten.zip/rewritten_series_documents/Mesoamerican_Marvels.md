# Mesoamerican Marvels

# The Maya Calendar: More Than Just 2012

## Series: The Cradles of Civilization

## The Cold Open: A Glimpse of the End

**(Visual: Eerie, atmospheric drone shot over dense jungle canopy, slowly revealing the crumbling, vine-covered ruins of a vast Maya city. Mist hangs heavy in the air. Sound of distant jungle wildlife, a haunting, low hum of wind.)**

**NARRATOR (Calm, authoritative, slightly melancholic):** December 21st, 2012. A date etched into modern consciousness, whispered with a mix of fear and fascination. The world braced itself, convinced by prophecies of cataclysm, of an ancient calendar reaching its final, apocalyptic conclusion.

**(Visual: Close-up on a weathered stela, intricate carvings barely visible beneath centuries of erosion. A single ray of sunlight pierces the canopy, illuminating a glyph.)**

**NARRATOR:** Yet, as the sun rose on December 22nd, the world remained. The ancient Maya, masters of time, had not foretold an end, but a transition. A grand cycle completed, another begun. But how did a civilization so profoundly connected to the cosmos become entangled in such a profound modern misunderstanding? How did their intricate dance with time, a testament to intellectual brilliance, become reduced to a doomsday clock? How did it come to this?

**(Visual: Quick cut to a modern, bustling city street, then back to the silent, ancient ruins. The contrast is stark. A single, resonant gong sound fades.)**

## Act I: The Genesis

**(Visual: Animated map showing Mesoamerica, highlighting the Yucatán Peninsula, Guatemala, and southern Mexico. Lush, vibrant greens. Sound of gentle rain and flowing water.)**

**NARRATOR:** Long before the whispers of 2012, in the verdant heart of Mesoamerica, a civilization emerged from the mists of time. Shaped by the rhythms of the jungle, the fertile plains, and the celestial ballet above, the Maya were born of their environment. Their world was alive, imbued with sacred meaning, and time itself was a living entity.

**(Visual: Artistic reconstruction of early Maya agricultural settlements, people tending crops, simple dwellings. Focus on the cyclical nature of planting and harvesting. Sound of birdsong and distant human activity.)**

**NARRATOR:** From humble agricultural beginnings, a distinct culture began to coalesce. Their observations of the natural world, particularly the movements of the sun, moon, and stars, were not merely scientific pursuits, but deeply spiritual endeavors. Time was not linear, but cyclical, a series of interlocking wheels, each turning within the other.

**(Visual: Depiction of a Maya shaman or priest observing the night sky, surrounded by early glyphs. Transition to images of early Maya deities, particularly those associated with creation and time. Sound of a low, rhythmic drumbeat.)**

**NARRATOR:** Their cosmology was rich, a tapestry woven with creation myths and the endless dance of deities. The world had been created and destroyed multiple times, each era marked by the end of a great cycle. This belief in cosmic cycles, in birth, death, and rebirth, formed the very bedrock of their understanding of existence, and it was this profound worldview that would give rise to one of humanity's most sophisticated calendrical systems.

## Act II: The Ascent & The Apex

**(Visual: Sweeping drone shot over Tikal or Palenque at its peak, bustling with activity. CGI reconstruction showing vibrant colors on buildings, people in traditional attire. Sound of distant chatter, music, and construction.)**

**NARRATOR:** As the Maya civilization ascended, so too did their mastery of time. Great city-states rose from the jungle, monuments to their intellectual prowess. Kings and queens, seen as intermediaries between the human and divine, commissioned vast temples and stelae, meticulously recording their reigns and the passage of cosmic time.

**(Visual: Close-up on a Maya scribe meticulously carving glyphs onto a stone monument. Transition to animated diagrams explaining the Haab' (365-day solar calendar) and the Tzolk'in (260-day sacred calendar), showing how they interlock to form the 52-year Calendar Round. Sound of stone carving, then a gentle, almost mathematical chime.)**

**NARRATOR:** Their calendrical system was not one, but many, working in elegant synchronicity. The 365-day *Haab'*, governing agricultural cycles, and the 260-day *Tzolk'in*, a sacred divinatory calendar, combined to form the 52-year Calendar Round. But for the grand sweep of history, for the tracking of cosmic eras, the Maya devised something truly extraordinary: the Long Count.

**(Visual: Animated representation of the Long Count calendar, showing the progression of k'in, winal, tun, k'atun, and baktun. Emphasize the base-20 and base-18 system. Show how dates are calculated and recorded. Sound becomes more complex, layered, reflecting the intricate system.)**

**NARRATOR:** The Long Count was a linear count of days from a mythical creation date, a vast, non-repeating system that allowed them to pinpoint any day in a span of millions of years. It was a testament to their advanced understanding of mathematics, including the concept of zero, and their unparalleled astronomical observations. At its apex, Maya civilization was a beacon of knowledge, its cities thriving, its scholars charting the heavens, and its priests meticulously recording the unfolding of time, believing that understanding the past was key to navigating the future.

## Act III: The Cracks in the Foundation

**(Visual: A subtle shift in atmosphere. The vibrant colors of the apex begin to desaturate slightly. A slow, panning shot over a once-grand plaza, now showing signs of neglect or overgrowth. Sound of wind whistling through ruins, a sense of unease.)**

**NARRATOR:** Yet, even at the height of their brilliance, the seeds of change, and ultimately decline, were being sown. The structural strengths that had propelled their ascent began to show cracks. The intricate balance between powerful city-states, once a source of innovation, devolved into endemic warfare. Resources, once abundant, became strained under the pressure of growing populations and changing environmental conditions.

**(Visual: Animated sequence depicting deforestation and soil erosion in the Maya lowlands. Overlay with glyphs representing drought or conflict. Transition to images of internal strife, perhaps a depiction of a defeated ruler or a burning temple. Sound of distant thunder, then the clash of stone weapons.)**

**NARRATOR:** Disastrous wars between rival kingdoms, succession crises that destabilized political structures, and significant environmental shifts—prolonged droughts, in particular—began to take their toll. The delicate ecological balance of the Maya lowlands was disrupted, leading to agricultural failures and widespread famine. The very elites who had driven the civilization's growth may have contributed to its downfall, their increasing demands on the populace and their lavish displays of power potentially leading to social inequality and unrest.

**(Visual: Close-up on a glyph depicting a calendar cycle ending, but with a subtle, ominous undertone. The light is dimming. Sound of a single, mournful flute.)**

**NARRATOR:** The meticulous recording of time continued, but the narratives shifted. The grand pronouncements of victory and prosperity were increasingly interspersed with accounts of hardship and conflict. The cycles of time, once a source of cosmic order, now seemed to reflect an earthly unraveling. The Long Count continued its inexorable march, but the world it measured was changing, irrevocably.

## Act IV: The Collapse & The Echo

**(Visual: Drone shot over a deserted, overgrown Maya city. The jungle has reclaimed much of it. The sense of loss is palpable. Sound of wind, rustling leaves, and the distant calls of unseen animals.)**

**NARRATOR:** The final decline of the Classic Maya was not a sudden cataclysm, but a complex, protracted process. One by one, the great cities of the southern lowlands were abandoned. Populations dispersed, monumental construction ceased, and the intricate network of trade and political alliances fractured. The jungle, ever patient, began to reclaim its own.

**(Visual: Images of post-Classic Maya settlements, smaller and more dispersed, but still vibrant. Focus on the continuity of Maya culture, even after the collapse of the Classic period. Sound of traditional Maya music, softer and more resilient.)**

**NARRATOR:** Yet, this was not an end, but a transformation. The Maya people endured. Their culture, their languages, and their profound understanding of the cosmos persisted, albeit in new forms and new locations. What was lost were the grand city-states of the Classic period, the centralized power structures, and the monumental inscriptions. What remained was the spirit of a people, their knowledge, and crucially, their calendars.

**(Visual: Close-up on a modern Maya elder, perhaps explaining a calendar wheel or traditional weaving. Connect the ancient knowledge to contemporary practices. Transition to a shot of the night sky, stars twinkling. Sound of a gentle, hopeful melody.)**

**NARRATOR:** The Long Count calendar, which had begun its current cycle on August 11, 3114 BCE, reached its conclusion on December 21, 2012. For the Maya, this was not an apocalypse, but the completion of a *baktun*, a grand cycle of 144,000 days. It was a moment of renewal, a time for reflection and the beginning of a new era, just as a clock resets at midnight. The modern world's misinterpretation was a projection of its own anxieties onto an ancient, sophisticated system.

**(Visual: A final, majestic shot of a Maya pyramid, perhaps at sunrise, symbolizing enduring legacy. The sun casts long shadows. Sound of a powerful, uplifting orchestral swell.)**

**NARRATOR:** The Maya calendar, far from being a harbinger of doom, stands as a monumental achievement of human intellect. It is an echo of a civilization that sought to understand its place in the cosmos, to chart the passage of time with unparalleled precision, and to remind us that endings are often just new beginnings. Their legacy is not one of collapse, but of enduring wisdom, a profound connection to the cycles of nature, and a timeless reminder that time, in its grandest sense, is an eternal journey, not a destination.

---


# Video Script: Tikal: The Great City in the Jungle

## Introduction

This video explores the rise and fall of Tikal, one of the most powerful kingdoms of the ancient Maya, blending atmospheric storytelling with analytical insights into its societal structures and environmental challenges.

## The Cold Open: A Glimpse of the End

**(Visual: Drone shot slowly panning over the overgrown ruins of Tikal, mist rising through the jungle canopy. Focus on Temple I, partially obscured by trees. Eerie, melancholic music begins.)**

**Narrator (Calm, authoritative, empathetic tone):** *"Here, the jungle reclaims its own. Stone giants, once reaching for the heavens, now stand silent, swallowed by an emerald tide. The whispers of a forgotten empire echo through the leaves, a testament to a civilization that soared to unimaginable heights, only to vanish into the verdant embrace of time.*"

**(Visual: Close-up on intricate carvings on a stela, covered in moss. Hands gently brush away foliage to reveal glyphs. Sound of rustling leaves, distant jungle calls.)**

**Narrator:** *"In the heart of the Petén Basin, amidst the dense rainforest of modern-day Guatemala, lies Tikal. For centuries, it was a beacon of Maya power, a city of pyramids and palaces, a hub of art and intellect. But then, silence. What forces conspired to bring down this mighty city? How did a civilization so advanced, so dominant, ultimately succumb to the relentless pressures of its own making?"

**(Visual: Quick montage of vibrant Maya life – bustling markets, priests performing rituals, warriors in ceremonial attire – juxtaposed with rapid shots of drought-cracked earth, skeletal figures, and crumbling stone. Ends on a lingering shot of an empty, overgrown plaza.)**

## Act I: The Genesis

**(Visual: Animated map showing the geographical location of Tikal in the Petén Basin, highlighting its access to water sources and trade routes. Lush, vibrant jungle scenes.)**

**Narrator:** *"To understand Tikal, we must first understand its cradle: the vast, fertile, yet challenging Petén rainforest. This was a land of abundance and scarcity, where seasonal rains brought life-giving water, but also periods of intense drought. It was here, in this dynamic environment, that the earliest Maya settlers began to carve out an existence, transforming the dense jungle into a landscape capable of sustaining complex societies."

**(Visual: Reconstructions of early Maya settlements, simple thatched huts evolving into more permanent structures. Focus on agricultural practices like raised fields and water management systems.)**

**Narrator:** *"From humble beginnings, small agricultural communities coalesced, drawn together by shared beliefs and the need for collective effort. They mastered their environment, developing sophisticated water management systems and agricultural techniques that allowed them to feed a growing population. Their worldview was deeply intertwined with the cosmos, with powerful deities governing the cycles of life, death, and rebirth. The sacred ceiba tree, connecting the underworld, earth, and heavens, symbolized their spiritual universe."

**(Visual: Artistic rendering of early Maya rituals, priests gazing at the stars, glyphs depicting creation myths.)**

## Act II: The Ascent & The Apex

**(Visual: Time-lapse animation showing the growth of Tikal from a small settlement to a sprawling city, with pyramids and temples rising into the sky. Energetic, triumphant music.)**

**Narrator:** *"By the Classic Period, Tikal had emerged as a dominant force. Its rise was fueled by a combination of strategic alliances, military prowess, and an unparalleled ability to mobilize labor and resources. Kings like Yax Ehb' Xook, the legendary founder, laid the groundwork, but it was rulers like Jasaw Chan K'awiil I, who famously defeated Calakmul, that cemented Tikal's status as a regional superpower."

**(Visual: CGI reconstruction of Tikal at its peak: bustling plazas, vibrant murals, people engaged in various activities. Close-ups on intricate jade carvings, pottery, and architectural details.)**

**Narrator:** *"At its apex, Tikal was a marvel. Its Great Plaza, flanked by towering temples, was the beating heart of a city home to tens of thousands. Artisans produced exquisite works, astronomers charted the heavens with astonishing precision, and scribes recorded their history in complex hieroglyphs. This golden age was underpinned by a highly stratified society, with a powerful elite orchestrating vast public works and maintaining a delicate balance of power with rival city-states. Their structural strengths lay in their centralized authority, efficient agricultural systems, and a robust trade network that brought exotic goods from across Mesoamerica."

**(Visual: Animated trade routes, showing goods flowing into and out of Tikal. Scholars studying glyphs, warriors in battle.)**

## Act III: The Cracks in the Foundation

**(Visual: Subtle shift in music to a more somber, foreboding tone. Visuals begin to show signs of strain: slightly cracked stelae, less vibrant murals, hints of deforestation.)**

**Narrator:** *"Yet, even at its zenith, the seeds of Tikal's decline were being sown. The very systems that propelled its ascent began to show strain. Prolonged periods of drought, exacerbated by extensive deforestation for agriculture and construction, placed immense pressure on the city's water supply. The delicate ecological balance of the Petén was tipping."

**(Visual: Animated sequence showing increasing drought conditions, receding water levels in reservoirs. Overlaid graphs showing population growth versus resource depletion.)**

**Narrator:** *"Internally, the elite class grew, demanding more resources and labor, leading to what some historians term 'elite overproduction.' This placed an unsustainable burden on the common populace, potentially leading to social unrest and a weakening of the centralized authority. External pressures also mounted. Renewed conflicts with rival cities, particularly Calakmul, drained resources and manpower, creating a geopolitical landscape of constant tension and warfare."

**(Visual: Depictions of Maya warfare, increasingly brutal. Scenes of commoners struggling, perhaps a subtle hint of rebellion or discontent.)**

## Act IV: The Collapse & The Echo

**(Visual: The music becomes increasingly mournful. Shots of Tikal's temples slowly being engulfed by the jungle, rain pouring down on crumbling structures. Emphasize the sense of abandonment.)**

**Narrator:** *"The final century of Tikal's glory was marked by a series of cascading failures. Severe, prolonged droughts crippled agricultural output, leading to widespread famine and disease. The social contract between the rulers and the ruled fractured. Public works ceased, and the grand ceremonies that once bound the community together faded into memory. One by one, the great cities of the southern Maya lowlands, including Tikal, were abandoned."

**(Visual: Empty plazas, temples with vegetation growing through them. Close-ups on abandoned tools, pottery shards. A single, poignant shot of a child's toy left behind.)**

**Narrator:** *"The collapse was not a sudden, cataclysmic event, but a gradual unraveling, a slow retreat from the once-vibrant urban centers. The jungle, ever patient, began its relentless reclamation. What remained were the silent stone monuments, a testament to human ambition and vulnerability. The Maya people did not vanish; they dispersed, adapting to new ways of life, but the centralized power and monumental achievements of the Classic Period were lost."

**(Visual: Modern-day Maya people, living in harmony with the land, practicing traditional crafts. Connect their resilience to the legacy of Tikal.)**

**Narrator:** *"Tikal's echo resonates through history, a powerful reminder of the intricate dance between human society and its environment. It teaches us that even the most sophisticated civilizations are not immune to the consequences of ecological imbalance, social inequality, and relentless external pressures. The story of Tikal is not just a tale of collapse, but a profound lesson in resilience, adaptation, and the enduring spirit of a people who, even in silence, continue to speak to us across the millennia."

**(Visual: Final shot of Temple I, bathed in golden light, still majestic despite the overgrowth. Fade to black. End music.)**


---

# The Collapse of the Maya: What Really Happened?

## Series: Ancient Civilizations

## Video Package

### The Cold Open: A Glimpse of the End

**[Pictory Visual Prompt: Drone shot, slowly panning over dense, overgrown jungle canopy. Mist hangs heavy in the air. Gradually, the camera descends, revealing the crumbling, moss-covered stone structures of Tikal, partially reclaimed by nature. Eerie, melancholic music begins.]**

**Narrator (Calm, authoritative, empathetic tone):** The year is roughly 900 AD. The great cities of the Maya heartland, once vibrant centers of power, knowledge, and art, are falling silent. The intricate carvings on stelae, once proclaiming the triumphs of kings, now stand as mute witnesses to an exodus. The plazas, once teeming with life, are slowly being swallowed by the relentless embrace of the jungle.

**[Pictory Visual Prompt: Close-up on a weathered Maya glyph, then slowly zoom out to show a vast, empty courtyard. Sound of wind rustling through leaves, distant bird calls.]**

**Narrator:** *"All the people were gone. The cities were abandoned. The gods had departed."* So might a lone traveler have observed, wandering through the skeletal remains of what was once a magnificent civilization. A civilization that mastered astronomy, developed a sophisticated writing system, and built monumental cities without the wheel or metal tools.

**[Pictory Visual Prompt: Quick montage of ancient Maya life: bustling markets, priests performing rituals, astronomers observing stars, warriors in battle. Then, a sudden cut to silence and still images of ruins.]**

**Narrator:** How did such an advanced and seemingly robust society, flourishing for centuries, simply vanish from its urban centers? What unseen forces, what fatal flaws, led to the collapse of the Classic Maya? This is not merely a story of decline, but a profound historical mystery, an echo of vulnerability that resonates through the ages. How did it come to this?

### Act I: The Genesis

**[Pictory Visual Prompt: Animated map showing the geographical extent of the Maya civilization, highlighting the Yucatán Peninsula, Guatemala, Belize, and parts of Mexico, Honduras, and El Salvador. Lush green landscapes, rivers, and limestone karsts are emphasized. Gentle, ancient-sounding flute music begins.]**

**Narrator:** Our journey begins not with an end, but with a birth, deep within the verdant heart of Mesoamerica. The Maya civilization emerged from a landscape both bountiful and challenging: a vast, low-lying limestone shelf, rich in fertile soil, but lacking major rivers. Here, the rhythm of life was dictated by the annual cycle of rainfall, and the ingenious management of water became paramount.

**[Pictory Visual Prompt: Time-lapse of early Maya farmers clearing land and planting maize. Focus on the importance of maize cultivation. Then, visuals of cenotes (natural sinkholes) and chultuns (underground cisterns) as vital water sources.]**

**Narrator:** From humble agricultural communities, cultivating the sacred maize that formed the bedrock of their diet and cosmology, the Maya began to coalesce. Around 2000 BC, the first permanent settlements took root, slowly evolving into complex societies. By the Preclassic period, sophisticated urban centers like El Mirador began to rise, showcasing early monumental architecture and a burgeoning social hierarchy.

**[Pictory Visual Prompt: CGI reconstruction of El Mirador at its peak, showing massive pyramids and causeways. Focus on the scale and ambition of early Maya construction. Transition to images of early Maya pottery and jade artifacts.]**

**Narrator:** Their worldview was deeply intertwined with the cosmos and the natural world. The heavens were a living book, meticulously observed by priest-astronomers who charted the movements of planets and stars with astonishing accuracy. Time itself was cyclical, a grand narrative of creation and destruction, meticulously recorded through a complex calendar system. Their gods were powerful, often dualistic entities, demanding reverence and sacrifice, embodying the forces of creation, destruction, and renewal. The jaguar, the serpent, and the quetzal bird were not just animals, but sacred symbols, connecting the earthly realm to the divine.

**[Pictory Visual Prompt: Animated sequence showing the Maya calendar system, focusing on the Long Count. Then, artistic representations of Maya deities, particularly Kukulkan (feathered serpent) and the Jaguar God. Sound of ceremonial drums and chanting.]**

**Narrator:** This intricate tapestry of belief, innovation, and adaptation laid the foundation for one of the most remarkable civilizations the world has ever known. But even in this genesis, the seeds of future challenges were perhaps already being sown, hidden within the very systems that enabled their initial flourishing.

### Act II: The Ascent & The Apex

**[Pictory Visual Prompt: Sweeping drone shot over the fully restored city of Tikal at sunrise, showcasing its towering temples and grand plazas. The scene is bustling with CGI-generated Maya people in traditional attire, engaged in daily activities. Uplifting, majestic orchestral music begins.]**

**Narrator:** From the foundational period of the Preclassic, the Maya civilization ascended to its zenith during the Classic period, roughly from 250 to 900 AD. This was an era of unprecedented growth, innovation, and cultural flourishing. Cities like Tikal, Palenque, Copán, and Calakmul rose as powerful city-states, each a jewel in a decentralized, yet interconnected, network of political and economic influence.

**[Pictory Visual Prompt: Animated map showing the expansion of Maya influence, highlighting key city-states and trade routes. Focus on the political landscape of competing yet culturally unified polities. Transition to images of Maya stelae depicting powerful rulers.]**

**Narrator:** The rise to power was often driven by charismatic and ambitious rulers, known as *k\'uhul ajaw* or divine lords, who legitimized their authority through elaborate rituals, military conquests, and claims of direct lineage to the gods. Dynasties flourished, and monumental stelae were erected to commemorate their triumphs, their blood sacrifices, and their cosmic connections. These rulers were not just political leaders; they were the spiritual intermediaries between their people and the divine.

**[Pictory Visual Prompt: Close-up on the intricate carvings of a stela, then a CGI reconstruction of a Maya king in full regalia, overseeing a public ceremony. Sound of ceremonial music and distant crowd murmurs.]**

**Narrator:** At its apex, Maya society was a marvel of organization and intellectual achievement. Their cities were not merely ceremonial centers but thriving metropolises, supported by sophisticated agricultural techniques like raised fields and terracing, which allowed them to feed dense populations. Their understanding of mathematics, incorporating the concept of zero, and their advanced astronomical observations, led to an incredibly precise calendar system, far more accurate than any in Europe at the time.

**[Pictory Visual Prompt: Visuals of Maya agricultural terraces and raised fields. Then, animated sequence explaining the Maya numerical system and the concept of zero. Transition to a depiction of a Maya observatory, with priests charting stars.]**

**Narrator:** Art and architecture reached unparalleled heights. Pyramids soared towards the heavens, adorned with intricate stucco reliefs and vibrant murals. Ballcourts hosted ritualistic games, and elaborate palaces housed the elite. A complex writing system, hieroglyphic in nature, recorded their history, their myths, and their scientific knowledge on stelae, altars, and codices. This golden age was a testament to their ingenuity, their spiritual depth, and their ability to thrive in a challenging environment. Yet, even as they reached for the stars, the very foundations of their success were subtly shifting, setting the stage for the challenges to come.

**[Pictory Visual Prompt: Montage of various Maya artistic achievements: murals, pottery, jade masks, and a recreation of a ballgame in progress. End with a slow pan over a thriving Maya city, then a subtle, almost imperceptible crack appearing on a temple wall. Music fades to a low, ominous hum.]**

### Act III: The Cracks in the Foundation

**[Pictory Visual Prompt: A jarring cut from the thriving city to a parched, cracked earth. Dead crops, wilting trees. Sound of dry wind, distant thunder that never arrives. The majestic music from Act II slowly distorts and becomes dissonant.]**

**Narrator:** The golden age of the Classic Maya, for all its brilliance, was not without its inherent vulnerabilities. Beneath the veneer of prosperity and monumental achievement, subtle fissures began to appear, widening over centuries until the very foundations of their civilization were compromised. The delicate balance between human ambition and environmental capacity, once meticulously managed, started to fray.

**[Pictory Visual Prompt: Animated sequence showing deforestation: trees being cut down, land cleared for agriculture and construction. Then, visuals of soil erosion and declining agricultural yields. Focus on the impact of intensive farming on the fragile ecosystem.]**

**Narrator:** One of the most significant pressures was environmental degradation. The Maya heartland, while fertile, was also ecologically sensitive. The demands of a rapidly growing population, coupled with the insatiable need for timber for construction and fuel, led to widespread deforestation. This, in turn, exacerbated soil erosion and altered local rainfall patterns, making the land less productive and more susceptible to drought.

**[Pictory Visual Prompt: Satellite imagery or animated map showing the spread of prolonged drought across the Maya lowlands. Visuals of empty reservoirs, people struggling to find water. Sound of desperate murmurs and a ticking clock.]**

**Narrator:** Compounding these issues were periods of prolonged and severe drought, particularly during the 9th century. While the Maya had developed sophisticated water management systems, these were ultimately overwhelmed by the scale and duration of these climatic shifts. The lifeblood of their civilization – water – became a scarce and precious commodity, leading to widespread crop failures and famine.

**[Pictory Visual Prompt: Dynamic animation of Maya city-states engaging in fierce warfare. Focus on burning temples, captured rulers, and the destruction of infrastructure. Sound of battle, war cries, and the shattering of pottery.]**

**Narrator:** As resources dwindled, competition between the once-interconnected city-states intensified. The elaborate ritualistic warfare of earlier periods escalated into destructive, total conflicts. Archaeological evidence points to increased fortifications, the desecration of rival cities, and the capture and sacrifice of enemy rulers. This constant state of internecine conflict drained resources, disrupted trade routes, and destabilized the political landscape, preventing any unified response to the growing environmental crisis.

**[Pictory Visual Prompt: Visuals depicting social unrest: commoners looking emaciated, elites in opulent attire. Focus on the growing disparity. Then, a scene of a disgruntled commoner looking up at an unyielding priest-king. Sound of murmuring discontent, then a sudden, sharp crack.]**

**Narrator:** Internally, the social contract began to unravel. The divine lords, whose power was predicated on their ability to mediate with the gods and ensure prosperity, found their authority challenged as droughts persisted and harvests failed. The burden on the common populace, already strained by tribute and labor demands for monumental construction and warfare, became unbearable. This elite overproduction, where the ruling class grew in size and demand while the productive capacity of the land diminished, created a widening chasm of inequality and discontent. The cracks in the foundation were no longer subtle; they were deep, visible, and threatening to bring down the entire edifice.

### Act IV: The Collapse & The Echo

**[Pictory Visual Prompt: A desolate, abandoned Maya city. Rain falls heavily, washing over crumbling structures. The sound of rain and distant thunder, no human sounds. The ominous hum from Act III intensifies, then fades to a mournful, echoing melody.]**

**Narrator:** The 9th century witnessed the profound and enigmatic collapse of the Classic Maya civilization in the southern lowlands. It was not a sudden, cataclysmic event, but a protracted unraveling, a slow abandonment of once-great cities. One by one, the urban centers that had defined their golden age fell silent. Construction ceased, stelae were no longer erected, and the elaborate courtly life vanished.

**[Pictory Visual Prompt: Animated map showing the progressive abandonment of Maya cities in the southern lowlands, moving from east to west. Ghostly outlines of cities fading from the map. Focus on the scale of the depopulation.]**

**Narrator:** The precise mechanisms of this collapse are still debated, but the confluence of environmental stress, intensified warfare, and social upheaval proved to be an insurmountable challenge. As droughts persisted and agricultural yields plummeted, the population, once numbering in the millions, dwindled dramatically. People migrated from the heartland, seeking sustenance and stability in other regions, or simply dispersed into smaller, self-sufficient communities.

**[Pictory Visual Prompt: Visuals of Maya people migrating through dense jungle, carrying their few possessions. Focus on their weary faces, the sense of loss and displacement. Then, close-ups of abandoned artifacts, pottery shards scattered on the ground.]**

**Narrator:** The divine kings, once the linchpins of Maya society, lost their legitimacy. Their inability to conjure rain, to ensure bountiful harvests, or to protect their people from constant warfare, eroded faith in their sacred authority. The elaborate political and religious systems that had sustained the Classic period fractured, giving way to a more decentralized and less hierarchical social order.

**[Pictory Visual Prompt: A broken stela, half-buried in the earth. A CGI representation of a Maya priest-king looking distraught, his power visibly diminished. Sound of a single, mournful flute.]**

**Narrator:** What remained? The jungle, ever patient, reclaimed its dominion. Temples became hills, plazas became clearings, and the intricate carvings were slowly consumed by moss and roots. Yet, the Maya people did not vanish. They adapted, they persisted. In the northern Yucatán, new centers like Chichen Itza and Mayapán rose to prominence in the Postclassic period, albeit with different political structures and cultural influences. The language, the calendar, and many core beliefs endured, carried forward by the descendants of the Classic Maya.

**[Pictory Visual Prompt: Transition from overgrown ruins to vibrant modern-day Maya communities. Focus on the faces of contemporary Maya people, their traditions, and their resilience. Uplifting, hopeful music begins to swell.]**

**Narrator:** The collapse of the Classic Maya serves as a powerful echo across time, a cautionary tale of the delicate interplay between human society, its environment, and its political structures. It reminds us that even the most sophisticated civilizations are not immune to the forces of change, and that unchecked growth, environmental degradation, and internal strife can lead to profound societal transformation. Their story is a testament not only to the fragility of empires but also to the enduring spirit of a people who, despite immense challenges, continue to thrive and preserve their rich heritage. The question of \'what really happened?\' is not just about the past, but a mirror reflecting our own present and future, urging us to understand the patterns of history before the cracks in our own foundations become too wide to mend.

**[Pictory Visual Prompt: Slow, sweeping drone shot, rising above the jungle canopy, revealing the vastness of the Maya landscape, with both ancient ruins and modern settlements visible. The sun sets, casting long shadows. Music swells to a powerful, reflective crescendo, then fades to silence.]**



---

# Tenochtitlan: The Venice of the New World

## Series: The Cradles of Civilization

## The Cold Open: A Glimpse of the End

**Visuals:**
*   **Pictory Prompt:** Drone shot, mist-shrouded ruins of Tenochtitlan (CGI reconstruction), haunting music, slow pan over crumbling temples and overgrown canals. Focus on the contrast between past grandeur and present decay.
*   **Pictory Prompt:** Close-up on a weathered stone carving, rain dripping, emphasizing the passage of time.

**Narrator (Voiceover, calm, authoritative, empathetic):**

"*And when we saw so many cities and villages built in the water, and other great towns on dry land, and that straight and level causeway going to Mexico, we were amazed and said that it was like the enchantments they tell of in the legend of Amadis, on account of the great towers and cues and buildings rising from the water, and all built of masonry. And some of our soldiers even asked whether the things that we saw were not a dream.*"

— Bernal Díaz del Castillo, *The Conquest of New Spain*

**Narrator:** A dream, indeed. A city born of prophecy, built on a lake, a marvel of engineering and human will. Tenochtitlan, the beating heart of the Aztec Empire, a metropolis of shimmering canals, towering pyramids, and bustling markets. A city that defied its environment, transforming a marshy island into a vibrant urban center, home to hundreds of thousands.

**Visuals:**
*   **Pictory Prompt:** Quick montage of vibrant, pre-conquest Tenochtitlan (CGI reconstruction): bustling markets, canoes on canals, priests on temple summits, warriors in colorful regalia.

**Narrator:** Yet, within a few short years, this magnificent city, this Venice of the New World, would lie in ruins. Its temples burned, its causeways shattered, its people scattered. How could such a powerful, sophisticated civilization vanish so completely? What forces, both internal and external, conspired to bring about the downfall of this imperial city? This is the story of Tenochtitlan, and the echoes of its collapse still resonate today.

**Visuals:**
*   **Pictory Prompt:** Fade to black, then a single, lingering shot of a skull or a broken artifact from Tenochtitlan, emphasizing the fragility of empires.

## Act I: The Genesis

**Visuals:**
*   **Pictory Prompt:** Animated map showing the migration of the Mexica people from Aztlán, gradually moving south into the Valley of Mexico. Highlight key geographical features: lakes, mountains, existing settlements.
*   **Pictory Prompt:** Overhead shot of the Valley of Mexico (modern day, then CGI overlay of ancient landscape), emphasizing the lake system and volcanic peaks.

**Narrator:** Our story begins not with a city, but with a prophecy. The Mexica, a nomadic people, wandered the arid lands of northern Mexico, searching for a sign from their patron god, Huitzilopochtli. That sign: an eagle perched on a prickly pear cactus, devouring a serpent. A seemingly impossible vision, yet it would lead them to the most improbable of locations: a small, marshy island in the vast Lake Texcoco.

**Visuals:**
*   **Pictory Prompt:** Artistic rendering of the eagle, cactus, and serpent prophecy, perhaps in a codex style.
*   **Pictory Prompt:** Close-up on the marshy island, early Mexica settlers building rudimentary dwellings, driving piles into the lakebed.

**Narrator:** The Valley of Mexico, a high-altitude basin surrounded by volcanoes, was already home to established city-states. The Mexica, latecomers and perceived as barbarians, were initially vassals, mercenaries, and outcasts. But their resilience, their fierce devotion to Huitzilopochtli, and their strategic acumen would soon set them apart. They learned to adapt to their challenging environment, transforming the lake into their greatest asset.

**Visuals:**
*   **Pictory Prompt:** Time-lapse CGI showing the construction of chinampas (floating gardens), demonstrating the ingenuity of the Mexica in reclaiming land from the lake.
*   **Pictory Prompt:** Close-up on agricultural bounty from chinampas: maize, beans, squash.

**Narrator:** From these humble beginnings, a unique culture began to coalesce. Their worldview was shaped by a profound connection to the cosmos, a cyclical understanding of time, and a belief in the constant struggle between opposing forces. Human sacrifice, often misunderstood, was for them a sacred duty, a way to nourish the gods and ensure the continuation of the world. It was a brutal necessity in a world they perceived as constantly on the brink of cosmic collapse.

**Visuals:**
*   **Pictory Prompt:** Depiction of Aztec cosmology: sun god Huitzilopochtli, earth goddess Coatlicue, perhaps from a codex or temple carving.
*   **Pictory Prompt:** Stylized, respectful depiction of a ritual sacrifice, emphasizing its ceremonial nature rather than gore. Focus on priests, offerings, and the solemnity of the event.

**Narrator:** This was the genesis of a civilization that would, against all odds, rise to dominate Mesoamerica. A civilization forged in adversity, driven by prophecy, and sustained by an intricate web of religious belief, agricultural innovation, and military prowess. But the very foundations that allowed them to flourish would also contain the seeds of their eventual undoing.

## Act II: The Ascent & The Apex

**Visuals:**
*   **Pictory Prompt:** Animated map showing the expansion of the Aztec Triple Alliance across Mesoamerica. Highlight key conquests and tributary states.
*   **Pictory Prompt:** CGI reconstruction of Tenochtitlan at its peak: bustling markets, grand temples, causeways teeming with people, aqueducts bringing fresh water.

**Narrator:** From their island stronghold, the Mexica, alongside their allies in Texcoco and Tlacopan, forged the formidable Triple Alliance, the engine of the Aztec Empire. Through a combination of military might, shrewd diplomacy, and a sophisticated tribute system, they rapidly expanded their dominion. Conquered city-states were not always directly governed, but rather compelled to pay tribute in goods, labor, and sacrificial victims, fueling Tenochtitlan's growth and power.

**Visuals:**
*   **Pictory Prompt:** Depiction of Aztec warriors in battle, emphasizing their discipline and weaponry (obsidian-edged swords, atlatls).
*   **Pictory Prompt:** Scenes of tribute collection: vast quantities of maize, cacao, precious feathers, gold, and jade being brought into Tenochtitlan.

**Narrator:** At its apex, Tenochtitlan was arguably the largest and most magnificent city in the Americas, a true marvel of urban planning. Its population swelled to an estimated 200,000 to 300,000 inhabitants, supported by the ingenious *chinampa* system that provided abundant food. The city was a network of canals and causeways, punctuated by monumental architecture. The Templo Mayor, dedicated to Huitzilopochtli and Tlaloc, stood at its spiritual and physical heart, a towering testament to their devotion and power.

**Visuals:**
*   **Pictory Prompt:** Detailed CGI flyover of the Templo Mayor complex, showing its twin shrines and surrounding ceremonial precinct.
*   **Pictory Prompt:** Close-up on intricate Aztec artistry: featherwork, gold jewelry, stone sculptures.

**Narrator:** The structural strengths of the Aztec Empire were multifaceted. Their military was highly organized and effective, ensuring the flow of tribute. Their economic system, centered on the vast market of Tlatelolco, facilitated trade and distribution across the empire. Their religious ideology, which intertwined warfare with cosmic sustenance, provided a powerful unifying force. Education was highly valued, with specialized schools for nobles and commoners alike, fostering a literate and skilled populace. This was a society that had mastered its environment, organized its people, and projected its power with unparalleled efficiency. Yet, beneath this glittering surface, the very mechanisms that propelled its ascent were simultaneously sowing the seeds of its eventual decline. The constant demand for tribute and sacrificial victims created deep-seated resentment among subjugated peoples, a simmering discontent that would prove catastrophic when an unforeseen external force arrived.

## Act III: The Cracks in the Foundation

**Visuals:**
*   **Pictory Prompt:** Animated map showing the extent of the Aztec Empire, with areas of unrest or recent conquest highlighted. Perhaps a visual representation of tribute routes and the burden on subjugated peoples.
*   **Pictory Prompt:** Artistic rendering of a succession crisis or internal political intrigue within the Aztec court, emphasizing tension and division.

**Narrator:** The Aztec Empire, for all its outward splendor, was a mosaic of conquered peoples, many of whom resented the heavy tribute demands and the constant need to provide sacrificial victims for Tenochtitlan's hungry gods. This simmering discontent was a fundamental structural weakness. The Tlaxcalans, fierce rivals who had successfully resisted Aztec domination, stood as a constant reminder of this internal fragility, a ready ally for any external force seeking to destabilize the empire.

**Visuals:**
*   **Pictory Prompt:** Depiction of Tlaxcalan warriors, distinct from Aztec, emphasizing their independence and martial prowess.
*   **Pictory Prompt:** Visual metaphor for the growing burden of tribute: a scale tipping heavily, or a chain of people carrying heavy loads towards Tenochtitlan.

**Narrator:** Beyond the political tensions, there were ecological pressures. While the chinampas were highly productive, the sheer scale of Tenochtitlan's population placed immense strain on the Valley of Mexico's resources. Deforestation for construction and fuel, coupled with occasional droughts or floods, could lead to food shortages and exacerbate social unrest. The delicate balance between human activity and the natural environment was constantly tested, a pattern seen in many collapsing civilizations.

**Visuals:**
*   **Pictory Prompt:** Visual representation of environmental stress: parched fields, low lake levels, or denuded hillsides (CGI).
*   **Pictory Prompt:** Scenes of social stratification: opulent Aztec nobles contrasted with struggling commoners, hinting at growing inequality.

**Narrator:** The very success of the empire, in a sense, contributed to its vulnerabilities. The constant expansion and the influx of tribute created a large, powerful elite, potentially leading to what historians call 'elite overproduction.' Too many nobles vying for too few positions of power and wealth could breed internal rivalries and weaken the central authority. This internal fracturing, combined with the resentment of subjugated peoples and environmental strains, created a complex web of vulnerabilities, a tinderbox awaiting a spark.

## Act V: The Collapse & The Echo

**Visuals:**
*   **Pictory Prompt:** Spanish caravels approaching the coast, a stark contrast to indigenous canoes. Emphasize the technological disparity.
*   **Pictory Prompt:** Hernán Cortés and his conquistadors, perhaps meeting with indigenous allies like the Tlaxcalans. Highlight the alliances formed against the Aztecs.

**Narrator:** The spark arrived in 1519, in the form of Hernán Cortés and his small band of Spanish conquistadors. They were not merely invaders; they were a catalyst, exploiting the deep-seated resentments and structural weaknesses within the Aztec Empire. The Tlaxcalans, seeing an opportunity for liberation, eagerly joined forces with the Spanish, providing crucial manpower and knowledge of the local terrain.

**Visuals:**
*   **Pictory Prompt:** Animated map showing the Spanish advance towards Tenochtitlan, highlighting key battles and the growing coalition of indigenous forces.
*   **Pictory Prompt:** Depiction of the initial meeting between Moctezuma II and Cortés, perhaps with an ominous undertone.

**Narrator:** The initial encounter between Moctezuma II and Cortés was marked by a fatal misunderstanding. Moctezuma, perhaps influenced by prophecies, initially welcomed the Spanish, a decision that would prove disastrous. The Spanish, with their steel weapons, firearms, and horses, possessed a technological advantage, but it was the invisible enemy—smallpox—that truly decimated the indigenous population, including the defenders of Tenochtitlan.

**Visuals:**
*   **Pictory Prompt:** Visual representation of smallpox spreading through the population, perhaps through abstract imagery or historical accounts of its devastating effects.
*   **Pictory Prompt:** Scenes of intense urban warfare in Tenochtitlan: Spanish and allied forces fighting on causeways, in canals, and around temples. Emphasize the ferocity of the resistance.

**Narrator:** The siege of Tenochtitlan was a brutal, protracted affair. For 93 days, the city's defenders, weakened by disease and starvation, fought valiantly. But ultimately, the combined might of the Spanish and their indigenous allies, coupled with the devastating impact of smallpox, proved insurmountable. On August 13, 1521, Tenochtitlan fell. The magnificent city, once a symbol of Aztec power, was systematically dismantled, its temples razed, its canals filled, and its stones used to build the foundations of a new colonial capital: Mexico City.

**Visuals:**
*   **Pictory Prompt:** Time-lapse CGI showing the destruction of Tenochtitlan and the gradual construction of Mexico City over its ruins.
*   **Pictory Prompt:** A modern-day shot of Mexico City's Zócalo, with the Metropolitan Cathedral built over the Templo Mayor, symbolizing the layered history.

**Narrator:** The immediate aftermath was catastrophic. A civilization, vibrant and complex, was shattered. Its political structures collapsed, its religious practices suppressed, and its people subjected to a new order. What was lost was immeasurable: vast libraries of knowledge, unique artistic traditions, and an entire way of life. Yet, the echo of Tenochtitlan persists. The indigenous languages, customs, and genetic heritage of the Mexica and other Mesoamerican peoples continue to thrive in modern Mexico. The very layout of Mexico City still bears the imprint of the ancient Aztec capital, its streets following the lines of ancient causeways.

**Visuals:**
*   **Pictory Prompt:** Montage of modern Mexican culture, showing indigenous influences in art, food, and festivals.
*   **Pictory Prompt:** Final shot: a panoramic view of Mexico City, with a subtle overlay of ancient Tenochtitlan, emphasizing the enduring legacy.

**Narrator:** Tenochtitlan's story is a powerful reminder of the fragility of even the most powerful empires, and the complex interplay of internal vulnerabilities and external shocks. It teaches us about the resilience of cultures, the enduring power of human ingenuity, and the profound, often tragic, consequences of collision between vastly different worlds. The Venice of the New World may have fallen, but its spirit, its legacy, continues to flow through the veins of a nation, an eternal echo in the heart of Mexico.

---

# Human Sacrifice: The Dark Side of Aztec Religion

## Series: The Cradles of Civilization

## Video Package

### The Cold Open: A Glimpse of the End

**[VISUAL PROMPT: Extreme close-up on a obsidian blade, glinting under torchlight. Slow zoom out to reveal a priest, adorned in elaborate feathered regalia, holding the blade aloft over a bound figure on a sacrificial altar. The air is thick with incense and the rhythmic beat of drums. The scene is dark, atmospheric, and unsettling.]**

**(NARRATOR, calm, authoritative, slightly melancholic tone)**

"*Our hearts are rent, our blood flows, our lives are given to the sun, that he may live, that he may journey across the sky.*"

These are not the words of a desperate plea, but a sacred duty. A covenant etched in blood, believed to sustain the very cosmos. In the heart of a sprawling empire, amidst the shimmering waters of Lake Texcoco, a civilization rose to unparalleled heights, built on a foundation both magnificent and terrifying. They were the Mexica, the Aztecs, and their gods demanded a price. A price paid in the most precious currency imaginable: human life. How did a society capable of such architectural marvels, such intricate social structures, and such profound artistic expression, come to embrace a practice so utterly brutal? How did the beating heart of a human become the most vital offering to the sun?

**[VISUAL PROMPT: Transition to a wide shot of Tenochtitlan, a bustling metropolis of temples, canals, and markets, bathed in the golden light of dawn. The camera slowly pans across the city, emphasizing its grandeur, then subtly focuses on the towering Templo Mayor in the distance.]**

### Act I: The Genesis

**[VISUAL PROMPT: Animated map showing the migration of the Mexica from Aztlan to the Valley of Mexico, highlighting key geographical features like lakes and mountains. Overlay with ancient codex illustrations depicting their journey and early struggles.]**

**(NARRATOR)**

The story begins not with an empire, but with a nomadic tribe, the Mexica, wandering the arid lands of northern Mexico in search of a promised sign. Their patron deity, Huitzilopochtli, the Hummingbird-Left, god of war and sun, had commanded them: build your city where you find an eagle perched on a prickly pear cactus, devouring a serpent. This seemingly impossible prophecy led them, in the early 14th century, to a small, marshy island in the vast Lake Texcoco. It was an inhospitable place, shunned by the established city-states of the Valley of Mexico. Yet, here, they found their sign. And here, Tenochtitlan, the future heart of their empire, began to rise.

**[VISUAL PROMPT: CGI reconstruction of early Tenochtitlan, showing chinampas (floating gardens) being constructed, and rudimentary temples being erected. Focus on the ingenuity required to build a city on a lake.]**

**(NARRATOR)**

Their early existence was precarious, marked by servitude to more powerful neighbors and constant struggle. But from this hardship emerged a fierce, resilient culture, deeply intertwined with their demanding deities. The Mexica worldview was one of cosmic struggle, a constant battle between opposing forces. The sun, Tonatiuh, required daily nourishment to make its perilous journey across the sky and prevent the world from plunging into eternal darkness. This nourishment, they believed, was *chalchihuatl* – precious water, the sacred blood of humans. This belief, born from their harsh environment and the existential threat of cosmic collapse, laid the ideological groundwork for what would become the most defining, and most feared, aspect of their religion.

**[VISUAL PROMPT: Illustrations from the Codex Borgia or other pre-Columbian manuscripts depicting Huitzilopochtli and other Aztec deities, emphasizing their powerful and sometimes fearsome aspects. Close-ups on glyphs related to sacrifice and cosmic cycles.]**

### Act II: The Ascent & The Apex

**[VISUAL PROMPT: Time-lapse animation showing the rapid growth of Tenochtitlan from a small settlement to a sprawling imperial capital. Overlay with historical maps illustrating the expansion of the Aztec Triple Alliance.]**

**(NARRATOR)**

From their humble island beginnings, the Mexica forged alliances, waged relentless wars, and absorbed vast territories, culminating in the formation of the Triple Alliance with Texcoco and Tlacopan. By the early 15th century, they were the dominant power in Mesoamerica. Tenochtitlan blossomed into a magnificent city, a Venice of the New World, boasting an estimated 200,000 inhabitants. Its markets teemed with goods from across the empire, its canals bustled with canoes, and its monumental temples, particularly the Templo Mayor, soared towards the heavens, a testament to their power and piety.

**[VISUAL PROMPT: Detailed CGI reconstruction of the Templo Mayor during its prime, showing the twin shrines to Huitzilopochtli and Tlaloc. Focus on the intricate carvings, vibrant colors, and the sheer scale of the structure. Show priests performing rituals on the summit.]**

**(NARRATOR)**

At the apex of their power, the practice of human sacrifice became institutionalized, a central pillar of both religious devotion and imperial control. It was not a random act of savagery, but a meticulously orchestrated ritual, deeply embedded in their cosmology and social fabric. Sacrifices were performed for a multitude of reasons: to ensure bountiful harvests, to consecrate new temples, to mark calendrical cycles, and most crucially, to appease the sun god Huitzilopochtli and the rain god Tlaloc. Prisoners of war, often captured in ritualized conflicts known as \'Flower Wars,\' were the primary victims, their capture seen as a sacred duty, providing the gods with their vital sustenance. This system, while horrific to modern sensibilities, served to reinforce the Aztec state\'s authority, instill fear in conquered peoples, and bind the community through shared, albeit terrifying, religious experience. The structural strength of the empire, its ability to mobilize vast resources and manpower, was paradoxically linked to this constant demand for sacrificial victims, creating a self-perpetuating cycle of conquest and ritual.

**[VISUAL PROMPT: Reenactment or detailed illustration of a \'Flower War\' – stylized, ritualized combat between Aztec warriors and their enemies. Emphasize the objective of capturing, not killing, opponents. Follow with a depiction of a sacrificial procession, showing the solemnity and order of the event.]**

### Act III: The Cracks in the Foundation

**[VISUAL PROMPT: A subtle shift in visual tone – perhaps a slightly darker filter over the previous grand cityscapes. Show a close-up of a stone carving depicting a stern-faced tlatoani (ruler), then pan to a depiction of a commoner looking weary or fearful.]**

**(NARRATOR)**

Yet, even at its zenith, the Aztec empire harbored the seeds of its own undoing. The very system that fueled its expansion and religious fervor began to create internal and external pressures. The constant demand for sacrificial victims, while ideologically justified, placed an immense burden on conquered territories. These provinces were not merely expected to pay tribute in goods, but also in human lives, fostering deep resentment and a simmering desire for rebellion. The \'Flower Wars,\' initially a means of ritualized combat and warrior training, increasingly became a mechanism for securing a steady supply of captives, blurring the lines between sacred duty and imperial exploitation.

**[VISUAL PROMPT: Animated map showing the extent of the Aztec empire, with conquered provinces highlighted in a different color, and arrows indicating routes of tribute collection. Show illustrations of tribute being delivered, including captives.]**

**(NARRATOR)**

Furthermore, the sheer scale of human sacrifice, particularly under rulers like Ahuitzotl, who reportedly oversaw the sacrifice of tens of thousands at the dedication of the expanded Templo Mayor, may have pushed the boundaries of even Aztec societal acceptance. While the exact numbers are debated, the psychological impact of such widespread ritualized killing, coupled with the ever-present threat of being chosen as a victim or having loved ones taken, must have created a pervasive undercurrent of fear and anxiety. This elite overproduction of ritual violence, while intended to solidify cosmic order, inadvertently sowed discord and weakened the social cohesion it sought to maintain. The empire, for all its outward strength, was becoming increasingly brittle, its foundations subtly cracking under the weight of its own demanding ideology.

**[VISUAL PROMPT: Artistic depiction of the dedication ceremony of the Templo Mayor, emphasizing the vast crowds and the sheer number of sacrifices. Focus on the expressions of both priests and onlookers, hinting at a spectrum of emotions from awe to terror. Perhaps a subtle visual metaphor of a crack appearing in a stone wall.]**

### Act IV: The Collapse & The Echo

**[VISUAL PROMPT: A dramatic shift to a stormy, ominous sky over Tenochtitlan. Show Spanish ships appearing on the horizon of Lake Texcoco. The grandeur of the city is now juxtaposed with an impending sense of doom.]**

**(NARRATOR)**

The arrival of Hernán Cortés and his small band of conquistadors in 1519 was not merely an external invasion; it was the catalyst that exposed and exploited these deep-seated fissures within the Aztec empire. The Spanish, with their alien technology, their insatiable greed for gold, and their fervent Christian ideology, presented a threat unlike any the Mexica had ever encountered. But it was the alliances Cortés forged with disgruntled tributary states, eager to throw off the yoke of Aztec dominance and its bloody demands, that truly sealed the empire\'s fate.

**[VISUAL PROMPT: Animated battle sequences depicting the siege of Tenochtitlan, showing the ferocity of the fighting, the use of Spanish cannons and crossbows against Aztec obsidian weapons, and the devastating impact of smallpox. Focus on the desperation of the Aztec defenders.]**

**(NARRATOR)**

The siege of Tenochtitlan, a brutal, protracted struggle, saw the magnificent city reduced to rubble, its population decimated by warfare and disease. The Templo Mayor, once the beating heart of Aztec religious life, was systematically dismantled, its stones used to build a new colonial city. The gods, to whom so much blood had been offered, seemed to have abandoned their people. The immediate aftermath was a cultural and demographic catastrophe. A vibrant civilization, with its unique worldview and complex societal structures, was shattered, its traditions suppressed, its people subjugated.

**[VISUAL PROMPT: Juxtaposition of the ruins of Tenochtitlan with the emerging colonial Mexico City. Show indigenous people forced into labor, and Christian symbols replacing Aztec ones. A poignant shot of a single, surviving Aztec artifact amidst the new construction.]**

**(NARRATOR)**

Yet, the echo of the Aztec empire, and its dark side of human sacrifice, reverberates through history. It serves as a stark reminder of the profound differences in human belief systems, the lengths to which societies will go to maintain cosmic order, and the complex interplay between religion, power, and survival. While condemned by modern ethics, understanding Aztec sacrifice requires moving beyond simplistic judgments to grasp the intricate worldview that underpinned it – a worldview where the most precious gift was life itself, offered to ensure the continuation of the world. The legacy of the Aztecs, both their awe-inspiring achievements and their terrifying rituals, continues to challenge our understanding of civilization, reminding us that even the most advanced societies can harbor practices that, from another perspective, appear utterly alien and profoundly disturbing. Their story is a cautionary tale, a testament to the fragility of empires, and a powerful illustration of how deeply ingrained beliefs can shape the destiny of an entire people.

**[VISUAL PROMPT: Final shot: A slow, contemplative pan over modern Mexico City, with subtle hints of its Aztec past (e.g., archaeological sites, street names). End on a shot of the sun setting, perhaps with a faint, almost imperceptible, red hue, leaving the viewer with a sense of both loss and enduring mystery.]**

---

# The Conquest of the Aztec Empire

## The Cold Open: A Glimpse of the End

**(Visual Prompt: Pictory - Drone shot over modern Mexico City, slowly zooming out to reveal the vast urban sprawl. Overlay historical maps of Tenochtitlan, showing its original island location. Transition to CGI reconstruction of Tenochtitlan at its peak, bustling with life. Focus on the Templo Mayor.)**

**(Sound Design: Distant, echoing sounds of a bustling ancient city, gradually fading into the modern urban hum. A single, mournful Aztec flute melody begins to play.)**

**Narrator:** *"And when we saw all those cities and villages built in the water, and other great towns on dry land, and that straight and level causeway going to Mexico, we were amazed and said that it was like the enchantments they tell of in the legend of Amadis, on account of the great towers and cues and buildings rising from the water, and all built of masonry. And some of our soldiers even asked whether the things that we saw were not a dream."* - Bernal Díaz del Castillo, *The True History of the Conquest of New Spain*.

**(Visual Prompt: Pictory - Close-up on a weathered stone carving of an Aztec deity, then pan to a modern archaeological dig site, revealing layers of history. Show a quick montage of conflict: Spanish conquistadors clashing with Aztec warriors, then a shot of a burning temple.)**

**Narrator:** A dream, perhaps. A golden city, born from a prophecy, sustained by an empire of awe and fear. Yet, within a few short years, this marvel would lie in ruins, its gods silenced, its people subjugated. How did a civilization, at the zenith of its power, fall to a mere handful of outsiders? How did the heart of Mesoamerica, a vibrant tapestry of cultures and conquests, unravel so completely?

## Act I: The Genesis

**(Visual Prompt: Pictory - Animated map showing the migration of the Mexica people from Aztlán, across the arid northern lands, to the Valley of Mexico. Highlight key geographical features: lakes, mountains, volcanoes.)**

**(Sound Design: Wind howling across plains, then the gentle lapping of water. Indigenous chants begin softly.)**

**Narrator:** To understand the fall, we must first journey to the genesis. Our story begins not with an empire, but with a nomadic tribe, the Mexica, wandering the harsh landscapes of northern Mesoamerica. Driven by prophecy and a fierce will to survive, they sought a sign: an eagle perched on a prickly pear cactus, devouring a serpent. This was their destiny, foretold by their patron deity, Huitzilopochtli, the god of war and sun.

**(Visual Prompt: Pictory - Artistic rendition of the eagle, cactus, and serpent prophecy. Transition to early settlements in the Valley of Mexico, showing the challenges of marshland and hostile neighbors. Focus on agricultural innovations like chinampas.)**

**Narrator:** Their odyssey led them to the fertile, yet already crowded, Valley of Mexico in the 13th century. Surrounded by established city-states, the Mexica were initially scorned, forced to settle on a small, swampy island in Lake Texcoco. This seemingly inhospitable environment, however, would become their greatest asset. Through ingenuity and relentless labor, they transformed the marshlands into fertile *chinampas* – floating gardens that would feed a burgeoning population. This adaptation to their unique environment forged a resilient and disciplined people, laying the groundwork for their future dominance.

**(Visual Prompt: Pictory - Depiction of early Mexica society: warriors, priests, farmers. Emphasize their militaristic culture and the importance of tribute and alliances. Show the construction of early temples and causeways.)**

**Narrator:** Their early years were marked by subservience, serving as mercenaries for more powerful city-states. Yet, within this crucible of conflict, their martial prowess grew. They absorbed knowledge, honed their diplomatic skills, and began to forge strategic alliances. Their religious beliefs, centered on the cyclical nature of creation and destruction, and the necessity of human sacrifice to appease the gods and ensure the sun\'s rising, instilled a profound sense of purpose and a willingness to confront existential threats. This unique blend of environmental adaptation, military acumen, and a deeply ingrained spiritual worldview set the stage for the extraordinary rise of what would become the Aztec Empire.

## Act II: The Ascent & The Apex

**(Visual Prompt: Pictory - Animated map showing the expansion of the Triple Alliance (Tenochtitlan, Texcoco, Tlacopan) across Mesoamerica. Highlight key conquests and tributary states. Transition to CGI reconstruction of Tenochtitlan at its peak, emphasizing its architectural grandeur, causeways, aqueducts, and bustling markets.)**

**(Sound Design: Triumphant, rhythmic drumming. Sounds of a vibrant, thriving city: market chatter, distant ceremonial music.)**

**Narrator:** From their humble beginnings, the Mexica, through a series of strategic alliances and relentless military campaigns, forged the mighty Triple Alliance in 1428, commonly known as the Aztec Empire. Tenochtitlan, their island capital, became the beating heart of this vast dominion, a metropolis of unparalleled splendor. Its population swelled to hundreds of thousands, sustained by the ingenious *chinampa* system and a sophisticated network of tribute from conquered territories. Gold, jade, feathers, cacao, and human labor flowed into the capital, fueling an artistic and intellectual renaissance.

**(Visual Prompt: Pictory - Close-ups on Aztec art and artifacts: intricate featherwork, obsidian blades, codices depicting daily life and religious rituals. Show scenes of priests performing ceremonies at the Templo Mayor, warriors in full regalia, and scholars studying astronomical charts.)**

**Narrator:** At its apex, the Aztec Empire was a marvel of organization and innovation. Their legal system was complex, their astronomical observations precise, and their poetry profound. The Templo Mayor, dedicated to Huitzilopochtli and Tlaloc, the god of rain and fertility, stood as a monumental testament to their spiritual devotion and imperial power. The empire\'s structural strengths lay in its highly organized military, its efficient tribute system, and a shared religious ideology that legitimized its conquests. This pattern of expansion, resource extraction, and ideological integration mirrored the rise of many great empires throughout history, from Rome to the Inca, demonstrating a recurring historical dynamic of centralized power consolidating control over diverse populations.

## Act III: The Cracks in the Foundation

**(Visual Prompt: Pictory - Animated map showing the extent of the Aztec Empire, then highlight areas of discontent and unconquered enclaves like Tlaxcala. Show stylized depictions of tribute collection, with some scenes hinting at resentment among tributary states.)**

**(Sound Design: Subtle, unsettling dissonant notes begin to creep into the background music. Sounds of murmuring crowds, distant thunder.)**

**Narrator:** Yet, beneath the glittering facade of imperial power, cracks were beginning to form. The very engine of Aztec dominance—its insatiable demand for tribute and sacrificial victims—sowed the seeds of its own destruction. Conquered city-states, chafing under the heavy burden of taxation and the constant threat of their citizens being taken for sacrifice, harbored deep-seated resentment. The Tlaxcalans, a fiercely independent people, remained an unconquered thorn in the empire\'s side, a constant reminder of its limits and a potential rallying point for rebellion.

**(Visual Prompt: Pictory - Depiction of Montezuma II in his court, looking increasingly isolated and burdened. Show scenes of internal political intrigue, perhaps a stylized representation of elite overproduction – too many nobles, not enough meaningful roles, leading to factionalism. Transition to omens: comets, strange lights, and other supernatural signs as interpreted by Aztec priests.)**

**Narrator:** Internally, the reign of Emperor Montezuma II saw a growing centralization of power, which, while strengthening the emperor\'s authority, also alienated powerful nobles and fostered political instability. The concept of 
elite overproduction, where a growing number of educated and ambitious individuals compete for a limited number of high-status positions, may have contributed to a simmering discontent within the Aztec elite. Furthermore, a series of ominous omens—comets, strange lights in the sky, and prophetic dreams—were interpreted by Aztec priests as portents of impending doom, fostering a climate of anxiety and uncertainty. These internal stresses, combined with the external animosity of tributary states, created a volatile environment, ripe for disruption. The empire, for all its outward strength, was becoming increasingly brittle, a complex system under immense strain, awaiting an external shock to trigger its collapse.

## Act IV: The Collapse & The Echo

**(Visual Prompt: Pictory - Spanish ships arriving on the coast. Hernán Cortés and his conquistadors landing, meeting indigenous groups. Animated map showing Cortés\'s march inland, highlighting alliances with disgruntled native tribes, especially the Tlaxcalans.)**

**(Sound Design: Sound of waves, then the clang of armor, distant musket fire. A growing sense of foreboding.)**

**Narrator:** The external shock arrived in 1519, not from a rival Mesoamerican power, but from across the vast ocean. Hernán Cortés and his small band of Spanish conquistadors, driven by gold, glory, and religious zeal, landed on the shores of what is now Mexico. Their arrival was a geopolitical game-changer. Cortés, a shrewd and ruthless tactician, quickly recognized the deep-seated resentments simmering beneath the Aztec Empire\'s surface. He skillfully exploited these divisions, forging alliances with subjugated tribes, most notably the Tlaxcalans, who saw the Spanish as an opportunity to finally break free from Aztec dominance.

**(Visual Prompt: Pictory - Depiction of the initial meeting between Cortés and Montezuma II, emphasizing the cultural clash and Montezuma\'s initial hospitality. Show the \'Noche Triste\' – the Spanish retreat from Tenochtitlan, then their return with overwhelming force and siege. Focus on the devastating impact of smallpox.)**

**Narrator:** Montezuma II, caught between prophecy and pragmatism, initially welcomed Cortés into Tenochtitlan. This hospitality, however, quickly turned to captivity. The Spanish, with their superior weaponry—steel, gunpowder, and horses—and the psychological advantage of being perceived as divine or monstrous, held the city hostage. The inevitable clash erupted, leading to the infamous *Noche Triste*, where the Spanish were temporarily driven out. But Cortés returned, reinforced by thousands of native allies and, more devastatingly, by an invisible enemy: smallpox. The disease, to which the indigenous population had no immunity, ravaged Tenochtitlan, decimating its defenders and shattering their morale. The siege of Tenochtitlan was a brutal, protracted affair, culminating in the city\'s fall in August 1521.

**(Visual Prompt: Pictory - Ruins of Tenochtitlan, then the rapid construction of Mexico City over its foundations. Show images of cultural suppression, but also the syncretism of beliefs. Conclude with a shot of modern Mexico City, emphasizing the enduring legacy of both Aztec and Spanish cultures.)**

**Narrator:** The collapse was swift and catastrophic. The great city of Tenochtitlan was razed, its temples destroyed, its treasures plundered. The Aztec Empire, a civilization that had flourished for centuries, was extinguished. In its place rose New Spain, a colonial power that would forever reshape the continent. What remained? The language, the traditions, the genetic heritage of millions. The echo of the Aztec Empire resonates in modern Mexico, in its cuisine, its art, its vibrant culture, and in the enduring memory of a powerful civilization that, despite its fall, left an indelible mark on human history. The story of the Aztec conquest serves as a stark reminder of the fragility of empires, the devastating impact of cultural collision, and the complex interplay of internal vulnerabilities and external forces that can lead to the collapse of even the most formidable civilizations.

---

# Video Script: Machu Picchu: The Lost City of the Incas

**Series:** The Cradles of Civilization
**Topic:** Machu Picchu: The Lost City of the Incas

## Introduction

**(Cold Open: A Glimpse of the End)**

**(Visual: Drone shot slowly revealing the mist-shrouded peaks of the Andes, then zooming in on the iconic ruins of Machu Picchu, desolate and silent. Eerie, melancholic music swells.)**

**NARRATOR (Calm, authoritative, empathetic):** *"The sun, which had been their father, turned its face away. The stones, which had been their strength, stood silent witnesses to an emptiness profound."* (Quote adapted from historical accounts of the Spanish conquest and its aftermath).

**(Visual: Close-up on weathered stone, then a pan across empty terraces. Focus on intricate stonework, hinting at a lost civilization's genius.)**

**NARRATOR:** High in the Andean cloud forest, a city sleeps. For centuries, it lay hidden, a magnificent testament to a civilization that vanished, not with a bang, but with a whisper. Machu Picchu. The Lost City. But how did such a marvel rise to touch the sky, and why, in its moment of glory, did it fall into such profound silence? This is the story of a civilization's audacious dream, its breathtaking apex, and the subtle cracks that led to its enigmatic abandonment.

## Act I: The Genesis

**(Visual: Animated map showing the vastness of the Inca Empire, then focusing on the Urubamba Valley. Transition to lush, green Andean landscapes, showing the challenging terrain.)**

**NARRATOR:** To understand Machu Picchu, we must first understand the land that birthed it. The Andes. A spine of jagged peaks, a labyrinth of valleys, a land of extremes. Here, where the air is thin and the mountains dictate life, the Inca civilization emerged. Not from fertile plains, but from a relentless struggle against nature. Their genius lay in adapting, in transforming the impossible into the sustainable.

**(Visual: Early agricultural terraces, simple stone dwellings. Show archaeological reconstructions of early Inca settlements. Focus on the ingenuity of their farming techniques.)**

**NARRATOR:** From humble beginnings in the Cusco Valley, the Inca, or Tawantinsuyu – "The Four Quarters" – began to coalesce. Their worldview was deeply intertwined with the cosmos, with the sun god Inti, and the earth mother Pachamama. Every stone, every mountain, every river held spiritual significance. This spiritual connection, coupled with an unparalleled organizational capacity, laid the foundation for an empire that would stretch thousands of miles.

**(Visual: Depictions of Inca religious ceremonies, intricate textiles, and early pottery. Show the development of their unique cultural identity.)**

**NARRATOR:** They mastered high-altitude agriculture, developed sophisticated irrigation systems, and built a vast network of roads that unified disparate communities. Their early leaders, like Manco Cápac, were not just kings, but divine figures, guiding their people towards a destiny etched in stone and starlight. This was a civilization built on order, reciprocity, and an unshakeable belief in their divine mandate.

## Act II: The Ascent & The Apex

**(Visual: Time-lapse of Inca expansion on an animated map. Show images of powerful Inca rulers like Pachacuti. Focus on military might and strategic conquests.)**

**NARRATOR:** The 15th century witnessed the Inca's meteoric rise. Under visionary leaders like Pachacuti, the empire expanded with astonishing speed. Through a combination of military prowess, shrewd diplomacy, and an advanced administrative system, they absorbed diverse cultures, integrating them into a cohesive whole. The empire became a marvel of engineering and social organization.

**(Visual: CGI reconstruction of Cusco at its peak, with the Coricancha (Temple of the Sun) gleaming. Show bustling markets, intricate gold artifacts, and the advanced quipu record-keeping system.)**

**NARRATOR:** At its apex, the Inca Empire was the largest in pre-Columbian America. Its capital, Cusco, was a city of gold and meticulously cut stone, the navel of their world. And high above the sacred Urubamba River, Pachacuti commissioned a masterpiece: Machu Picchu. Not merely a city, but a royal estate, a sacred retreat, an astronomical observatory, and a strategic stronghold. Its construction defied the very laws of nature, a symphony of stone and spirit.

**(Visual: Detailed shots of Machu Picchu's architecture: perfectly fitted stones, agricultural terraces, the Intihuatana stone, the Temple of the Sun. Show how the city integrates with the natural landscape.)**

**NARRATOR:** The structural strengths of the Inca were manifold: a centralized command economy, a highly efficient labor system (the *mita*), and a profound understanding of their environment. Machu Picchu, with its precise astronomical alignments and earthquake-resistant architecture, stands as the ultimate expression of this ingenuity. It was a place where the Inca elite could commune with their gods, observe the celestial dance, and reaffirm their dominion over both man and nature. This was the golden age, a testament to human ambition and collective will.

## Act III: The Cracks in the Foundation

**(Visual: Subtle shift in music to a more ominous tone. Show images of internal strife, perhaps a stylized depiction of a succession crisis or a distant battle.)**

**NARRATOR:** Yet, even at its zenith, the seeds of decline were being sown. The very expansion that fueled Inca glory also created immense internal pressures. The constant need for new conquests to sustain the *mita* system, the integration of diverse and sometimes resistant populations, and the growing power of the elite created a delicate balance.

**(Visual: Visual metaphors for internal conflict: a crack appearing in a stone wall, a river diverging. Focus on the concept of elite overproduction – perhaps stylized graphics showing a growing number of nobles vying for limited resources and power.)**

**NARRATOR:** The concept of **elite overproduction**, a pattern observed in many complex societies, began to manifest. As the empire grew, so did the number of nobles, priests, and administrators. These elites, accustomed to privilege, increasingly competed for resources and influence, straining the empire's capacity to provide. This internal friction, though subtle, created fault lines within the seemingly monolithic structure of the Inca state.

**(Visual: Depictions of environmental challenges: a drought-stricken landscape, a flood. Show the impact of disease, perhaps a stylized representation of smallpox.)**

**NARRATOR:** Then came the external shocks. A devastating civil war erupted between half-brothers Huáscar and Atahualpa, tearing the empire apart from within. And as if summoned by fate, a far greater threat arrived from across the sea: the Spanish conquistadors, bringing with them not just steel and gunpowder, but an invisible, far more deadly weapon – disease. Smallpox, a silent harbinger of doom, decimated the Inca population even before Pizarro's arrival, weakening the empire's very foundations.

## Act IV: The Collapse & The Echo

**(Visual: Dramatic, somber music. Depictions of the Spanish conquest: Pizarro and his men, the capture of Atahualpa. Show the clash of two vastly different worlds.)**

**NARRATOR:** The civil war left the Inca Empire fractured and vulnerable. When Francisco Pizarro and his small band of conquistadors arrived in 1532, they found an empire reeling. The capture and execution of Atahualpa, the last independent Inca emperor, marked the beginning of the end. The Spanish, with their superior weaponry and the psychological advantage of being perceived as divine, systematically dismantled the Inca state.

**(Visual: Machu Picchu slowly being abandoned. Show the jungle reclaiming parts of the city. Focus on the mystery of its desertion – no signs of battle, just an orderly departure.)**

**NARRATOR:** But what of Machu Picchu? Unlike other Inca sites, it shows no signs of Spanish presence, no battle scars, no looting. It was simply... abandoned. The prevailing theory suggests that with the collapse of the Inca state, its purpose as a royal estate and sacred center ceased to exist. Its inhabitants, likely retainers and priests, simply left, perhaps to join the resistance or return to their ancestral lands. The jungle, ever patient, began its slow embrace, concealing the city for centuries.

**(Visual: Modern-day images of Machu Picchu, now a UNESCO World Heritage site, bustling with tourists. Reflective, hopeful music.)**

**NARRATOR:** The immediate aftermath of the conquest was catastrophic: cultural destruction, forced labor, and the decimation of indigenous populations. Yet, the echo of the Inca endures. Their agricultural techniques, their architectural marvels, and their spiritual connection to the land continue to inspire. Machu Picchu, rediscovered in 1911, stands as a powerful symbol of resilience, a window into a lost world, and a poignant reminder of the fragility of even the most magnificent civilizations.

**(Visual: Final sweeping drone shot of Machu Picchu at sunrise or sunset, emphasizing its timeless beauty and enduring mystery. Fade to black.)**

**NARRATOR:** The story of Machu Picchu is not just a tale of rise and fall, but a profound meditation on human ingenuity, the complex interplay of internal and external forces, and the enduring legacy of those who dared to build cities in the clouds. It asks us to consider: what are the unseen cracks in our own foundations, and what echoes will we leave behind?

---

# The Quipu: The Inca's Secret Code

## Series: The Cradles of Civilization

## The Cold Open: A Glimpse of the End

**[VISUAL: Dark, atmospheric shot of a dusty, ancient quipu hanging in a dimly lit museum display case. Zoom in slowly on the intricate knots. Eerie, melancholic music begins.]**

**NARRATOR (Calm, authoritative, empathetic):** In the vast, silent halls of history, some voices are forever silenced. Some stories, forever lost. We gaze upon their remnants, fragments of a forgotten world, and wonder: *What secrets did they hold?*

**[VISVISUAL: Close-up on a specific knot, then a quick cut to a flickering firelight illuminating an Inca scribe meticulously tying knots on a quipu. Sound of crackling fire and distant, faint panpipes.]**

**NARRATOR:** This, a quipu. A seemingly simple collection of knotted cords. Yet, for centuries, it was the beating heart of the largest empire in the pre-Columbian Americas – the Inca. A sophisticated system of record-keeping, a language of numbers, perhaps even of stories, woven into cotton and camelid fibers.

**[VISUAL: Transition to a wide, sweeping drone shot of the Andean mountains, majestic and imposing. The camera pans across ancient Inca terraces and ruins, hinting at a lost civilization.]**

**NARRATOR:** But then, silence. A sudden, brutal cessation. The arrival of steel and disease brought not just the collapse of an empire, but the deliberate destruction of its very memory. The quipu, once a vibrant conduit of knowledge, became an enigma. A secret code, deliberately unraveled, its meaning scattered to the winds of time.

**[VISUAL: A single, weathered quipu lies on a stone slab, partially covered by dust. The shot lingers, emphasizing the weight of lost knowledge.]**

**NARRATOR:** *How did a civilization of unparalleled organizational genius lose its voice so completely? And what might we still learn from the silent whispers of these ancient knots?*

## Act I: The Genesis

**[VISUAL: Bright, expansive shots of the high Andes. Focus on the diverse ecosystems – snow-capped peaks, fertile valleys, arid coastlines. Upbeat, traditional Andean music begins softly.]**

**NARRATOR:** To understand the quipu, we must first understand the land that birthed it. The Inca Empire, Tawantinsuyu, stretched across the formidable spine of the Andes, a land of extreme contrasts and immense challenges. From the arid coastal deserts to the humid Amazonian fringes, and the dizzying heights of the Altiplano, the Inca forged unity from diversity.

**[VISUAL: Animated map showing the gradual expansion of the Inca Empire from its origins in Cusco. Highlight key geographical features.]**

**NARRATOR:** In this challenging environment, where communication and administration across vast distances were paramount, the need for efficient record-keeping was not merely a convenience, but a necessity for survival and expansion. Unlike their Mesoamerican counterparts, the Inca did not develop a written script in the traditional sense. Instead, they innovated a system uniquely suited to their needs and materials.

**[VISUAL: Archeological reconstructions of early Inca settlements. Focus on communal work and resource management. Show early, simpler forms of knotted cords.]**

**NARRATOR:** The origins of the quipu are shrouded in the mists of pre-Inca history, with evidence suggesting its use by earlier Andean cultures. But it was the Inca who perfected it, transforming it into an administrative marvel. It became the backbone of their highly centralized state, managing everything from census data and tribute records to astronomical observations and historical narratives.

**[VISUAL: Close-up on hands demonstrating basic knot-tying techniques, perhaps with modern replicas of quipus. Explain the decimal system visually.]**

**NARRATOR:** At its core, the quipu was a three-dimensional, tactile system. A main cord, from which subsidiary cords hung, and from these, sub-subsidiary cords. Information was encoded in the type of fiber, the color of the cords, the direction of the ply, and, most importantly, the knots themselves. A decimal system, where the position and type of knot represented units, tens, hundreds, and thousands. It was a language of precision, a silent symphony of data.

## Act II: The Ascent & The Apex

**[VISUAL: Grand CGI reconstruction of Cusco at its peak, bustling with activity. Show the Qorikancha, Sacsayhuaman. Majestic, awe-inspiring music swells.]**

**NARRATOR:** With the quipu as its administrative nervous system, the Inca Empire ascended to its zenith. From the sacred city of Cusco, a vast network of roads, the Qhapaq Ñan, radiated outwards, connecting every corner of the empire. Along these roads, relay runners, the *chasquis*, carried messages and quipus, ensuring rapid communication and control.

**[VISUAL: Animation showing chasquis running along the Inca road system, passing quipus. Show different officials interacting with quipus – a tax collector, a census taker.]**

**NARRATOR:** The *quipucamayocs*, the master knot-keepers, were highly trained and revered officials. They were the living libraries of the Inca, capable of reading and interpreting the complex data stored within the knots. They were the guardians of the empire's collective memory, its history, its economy, and its very identity.

**[VISUAL: Close-up on a quipucamayoc, perhaps an older, wise-looking individual, carefully examining a quipu, his face etched with concentration. Show other quipucamayocs teaching younger apprentices.]**

**NARRATOR:** The quipu facilitated an astonishing level of social engineering and resource management. It allowed the Inca to track every llama, every bushel of maize, every subject within their vast domain. This meticulous record-keeping enabled the efficient allocation of resources, the organization of massive public works projects like Machu Picchu, and the smooth functioning of a complex tribute system. It was a testament to human ingenuity, a non-alphabetic solution to the universal challenge of information management, perfectly adapted to its environment and culture.

**[VISUAL: Time-lapse of Machu Picchu construction (CGI). Show the vastness of the Inca road network and the efficiency of their logistics, all enabled by the quipu.]**

**NARRATOR:** At its apex, the Inca Empire, powered by the silent language of the quipu, was a marvel of organization and control. It was a society built on precision, where every knot held a piece of the grand design, a testament to the power of data, even in an age without writing.

## Act III: The Cracks in the Foundation

**[VISUAL: The majestic Inca landscape begins to subtly shift. Clouds gather, shadows lengthen. The previously vibrant music becomes more somber, with a hint of foreboding.]**

**NARRATOR:** Yet, even at its zenith, the seeds of decline were being sown. The very strengths that propelled the Inca to greatness – their rigid hierarchy, their centralized control, their reliance on a single, non-alphabetic record-keeping system – would, in time, become their vulnerabilities. The vastness of the empire, while a testament to their power, also presented immense challenges in governance and cultural integration.

**[VISUAL: Animated map showing the internal divisions and ethnic groups within the Inca Empire. Highlight areas of potential unrest or recent conquest.]**

**NARRATOR:** The Inca expanded rapidly, often incorporating diverse and sometimes unwilling populations into their empire. While they were masters of assimilation, allowing conquered peoples to retain aspects of their culture, underlying resentments simmered. The tribute system, meticulously recorded by the quipu, could also be a source of grievance, particularly when local leaders felt their burdens were unfairly distributed.

**[VISUAL: A quipucamayoc looking stressed, perhaps struggling with a complex quipu, hinting at the increasing administrative burden. Show subtle signs of discontent among common people.]**

**NARRATOR:** A more profound crack emerged from within the ruling elite. The death of the Sapa Inca Huayna Capac around 1527, likely from smallpox introduced by the arriving Europeans, plunged the empire into a brutal civil war. His two sons, Huáscar and Atahualpa, vied for control, tearing the fabric of the empire apart. This internal conflict, a classic example of elite overproduction and competition for scarce resources (in this case, the ultimate power), fatally weakened the Inca state just as a new, existential threat loomed on the horizon.

**[VISUAL: Dramatic, stylized depiction of the civil war – perhaps two opposing armies clashing, or a visual metaphor for the empire tearing itself apart. The quipu, once a symbol of unity, now appears tangled and chaotic.]**

**NARRATOR:** The quipu, designed for stability and order, was ill-equipped to navigate the chaos of civil war. Its precise data, once a tool for efficient governance, now reflected a fractured reality. The very system that had bound the empire together began to unravel, knot by knot, as loyalties shifted and the central authority fractured. The silent language of the Inca, so powerful in times of peace, offered no defense against the cacophony of war.

**[VISUAL: A single, forgotten quipu lies discarded on the ground amidst the aftermath of a battle, symbolizing the breakdown of order.]**

**NARRATOR:** This internal strife, a self-inflicted wound, would prove to be the most devastating precursor to the empire's ultimate demise. The stage was set for a confrontation that the Inca, weakened and divided, were ill-prepared to face.

## Act IV: The Collapse & The Echo

**[VISUAL: The atmosphere darkens considerably. Ominous, heavy music begins. Shots of storm clouds gathering over the Andes, foreshadowing disaster.]**

**NARRATOR:** The year is 1532. Francisco Pizarro and his small band of Spanish conquistadors arrive on the shores of Peru. They are few in number, but armed with steel, gunpowder, and a relentless ambition. More potent than their weapons, however, were the invisible allies they carried: diseases like smallpox, which had already decimated the Inca population and claimed the life of their emperor.

**[VISUAL: Stylized depiction of the Spanish arrival – perhaps a single ship on a vast ocean, then a small group of armored figures against the backdrop of the immense Andes. Show the devastating impact of smallpox on the Inca population.]**

**NARRATOR:** Atahualpa, victorious in the civil war but still consolidating his power, gravely underestimated the threat. He agreed to meet Pizarro in Cajamarca, a decision that would seal the fate of his empire. In a brutal, swift ambush, the Spanish captured Atahualpa, massacring thousands of unarmed Inca. The symbolic head of the empire was severed, and with it, much of its will to resist.

**[VISUAL: Dramatic, almost abstract depiction of the ambush at Cajamarca – perhaps shadows and flashes of steel, emphasizing the suddenness and brutality. Focus on Atahualpa's capture.]**

**NARRATOR:** The quipu, once the repository of Inca knowledge and power, became a target. The Spanish, unable to comprehend its non-alphabetic logic and suspicious of its potential to organize resistance, systematically destroyed them. They saw them as pagan idols, tools of a defeated regime, or simply incomprehensible curiosities. A deliberate act of cultural erasure, aimed at dismantling the very administrative and historical memory of the Inca.

**[VISUAL: Shots of quipus being burned or destroyed by Spanish soldiers. Emphasize the loss and destruction. Perhaps a close-up of a quipu unraveling.]**

**NARRATOR:** The empire, already weakened by civil war and disease, crumbled. The remaining Inca resistance, though valiant, was ultimately futile against the superior weaponry and the psychological blow of their emperor's capture and execution. The great cities fell silent, the vast road network slowly decayed, and the intricate language of the quipu faded into obscurity.

**[VISUAL: Sweeping shots of abandoned Inca ruins, overgrown by vegetation. The music becomes mournful, reflective.]**

**NARRATOR:** But the echo of the quipu persists. Though its full meaning remains largely a mystery, a tantalizing secret code yet to be fully deciphered, it stands as a powerful testament to human ingenuity. It reminds us that knowledge takes many forms, and that the destruction of one system of understanding can leave an unfillable void. The quipu challenges our alphabetic biases, forcing us to consider alternative ways of recording and transmitting information.

**[VISUAL: Return to the museum shot of the quipu, but now with a sense of reverence and wonder. A scholar or researcher gently examines it, highlighting ongoing efforts to decipher it.]**

**NARRATOR:** What if we could fully unlock its secrets? What stories, what histories, what patterns of human civilization might these silent knots reveal? The quipu, the Inca's secret code, continues to whisper across the centuries, a poignant reminder of a lost world, and a powerful symbol of the enduring quest to understand our past. Its legacy is not just in what it recorded, but in the questions it continues to ask of us.

**[VISUAL: Fade to black. The melancholic music slowly fades out.]**


---

# The Inca Road: Engineering an Empire

## Series: The Cradles of Civilization

## I. The Cold Open: A Glimpse of the End

**(VISUAL: Drone shot soaring over the desolate, wind-swept peaks of the Andes. Focus on a single, crumbling stone path, barely visible against the vast landscape. The path is overgrown, hinting at forgotten grandeur. Eerie, melancholic music begins.)**

**(NARRATOR, calm, authoritative, empathetic tone):** "*The stones of the Qhapaq Ñan, the Great Inca Road, whisper tales of an empire that once spanned a continent. A network of arteries, pulsing with life, connecting mountain to coast, desert to jungle. But now, silence. Only the wind remembers the footsteps of chasquis, the burden of llamas, the decrees of the Sapa Inca. How did such a monumental achievement, a testament to human will and ingenuity, become a forgotten echo in the Andean vastness? How did it come to this?*"

**(VISUAL: Quick cuts of ancient Inca ruins, Machu Picchu shrouded in mist, then a close-up of a single, perfectly cut Inca stone, weathered by centuries. Fade to black.)**

## II. The Genesis

**(VISUAL: Animated map showing the gradual expansion of early Andean cultures. Focus on the challenging geography: high altitudes, deep valleys, arid coasts. Gentle, inquisitive music.)**

**(NARRATOR):** "Long before the Inca, the Andean world was a crucible of innovation. From the arid coastal deserts to the dizzying heights of the Altiplano, diverse peoples learned to coax life from an unforgiving land. The Moche, the Nazca, the Wari, the Tiwanaku – each civilization, in its own way, laid foundational stones. They mastered irrigation, terraced mountainsides, and built rudimentary paths to connect their scattered communities. The very landscape, a formidable barrier, forced a unique ingenuity. Survival demanded connection, and connection demanded roads."

**(VISUAL: Archeological reconstructions of early Andean settlements. Close-ups of ancient pottery, textiles, and agricultural terraces. Show early, unpaved trails winding through valleys.)**

**(NARRATOR):** "Their worldview was deeply intertwined with the mountains, the *apus*, and the sun, Inti. They believed in *ayni*, reciprocity, a cosmic balance that governed their relationship with nature and each other. This ethos of collective effort, of shared responsibility, would become the bedrock upon which the greatest road network in the ancient Americas would be built."

## III. The Ascent & The Apex

**(VISUAL: Time-lapse animation showing the rapid expansion of the Inca Empire from its heartland in Cusco. The Qhapaq Ñan spreads like a web across the map. Triumphant, epic music swells.)**

**(NARRATOR):** "From their humble origins in the Cusco valley, the Inca emerged, not just as conquerors, but as master organizers. Their genius lay not in inventing the wheel – which they famously did not use for transport – but in perfecting the art of integration. The Qhapaq Ñan, stretching over 40,000 kilometers, was more than just a road; it was the nervous system of an empire. It facilitated rapid communication via the *chasquis*, relay runners who could carry messages hundreds of kilometers in a single day. It moved armies, goods, and the very will of the Sapa Inca."

**(VISUAL: CGI reconstruction of Inca engineers surveying terrain, building suspension bridges over canyons, and carving roads into sheer rock faces. Show *chasquis* running, llamas laden with goods, and elaborate *tambos* (roadside inns).)

**(NARRATOR):** "At its apex, the Inca Empire, Tawantinsuyu, the 'Land of the Four Quarters,' was a marvel of centralized administration. Its cities, like Cusco, were vibrant centers of power and culture. The road allowed for the efficient collection of tribute, the redistribution of resources, and the rapid deployment of military forces, ensuring stability across a vast and diverse realm. This golden age was underpinned by a sophisticated understanding of logistics, labor organization (*mita*), and an unwavering commitment to engineering excellence. The very act of building and maintaining the road reinforced the empire's power and unity."

## IV. The Cracks in the Foundation

**(VISUAL: Subtle shift in music to a more ominous, foreboding tone. Show a visual metaphor for cracks appearing in a stone wall. Animated map highlighting areas of unrest or rebellion within the empire.)**

**(NARRATOR):** "Yet, even as the Qhapaq Ñan reached its zenith, internal pressures began to mount. The very efficiency of the road, designed for control, also became a conduit for discontent. The *mita* system, while effective, placed immense demands on conquered peoples, often forcing them far from their homes for imperial projects. This created resentment, simmering beneath the surface of imperial order. The rapid expansion also led to a phenomenon of 'elite overproduction' – too many nobles vying for limited power and resources, leading to internal rivalries and instability."

**(VISUAL: Depictions of Inca civil war, perhaps stylized. Show a *quipu* (Inca knot record) with a single knot unraveling. Focus on the faces of commoners, showing weariness and discontent.)**

**(NARRATOR):** "Then came the unseen enemy. Diseases, carried across oceans, raced ahead of the Spanish conquistadors, decimating populations and weakening the social fabric. The death of Sapa Inca Huayna Capac from smallpox plunged the empire into a brutal civil war between his sons, Huáscar and Atahualpa. The Qhapaq Ñan, once a symbol of unity, now became a highway for warring factions, further exhausting the empire's resources and tearing it apart from within."

## V. The Collapse & The Echo

**(VISUAL: Dramatic, tragic music. Show the arrival of the Spanish, a stark contrast to the Inca. Focus on the clash of cultures, steel against stone. The Qhapaq Ñan now used by Spanish horses and soldiers.)**

**(NARRATOR):** "When Francisco Pizarro and his small band of conquistadors arrived in 1532, they found an empire already on its knees, ravaged by disease and civil strife. The very roads that had unified the Inca now served as pathways for their conquerors. The Spanish, with their superior weaponry and ruthless tactics, exploited the internal divisions, capturing Atahualpa and dismantling the imperial structure with terrifying speed. The Qhapaq Ñan, once a testament to indigenous power, was repurposed, neglected, or deliberately destroyed."

**(VISUAL: Ruins of Inca cities, now desolate. Close-ups of indigenous people working under Spanish rule. Show sections of the road falling into disrepair, being reclaimed by nature.)**

**(NARRATOR):** "The immediate aftermath was catastrophic: the collapse of a sophisticated civilization, the loss of countless lives, and the suppression of a vibrant culture. Yet, the echo of the Inca Road persists. It is a UNESCO World Heritage site, a tangible link to a forgotten past. It reminds us of the enduring human capacity for organization, engineering, and adaptation in the face of immense challenges. The story of the Qhapaq Ñan is a powerful lesson in the fragility of empires, the interconnectedness of human endeavor, and the lasting legacy of those who dared to engineer an empire across the roof of the world."

**(VISUAL: Drone shot slowly pulling back from a restored section of the Qhapaq Ñan, now vibrant with local life, perhaps a modern hiker or a farmer. The sun sets over the Andes. Hopeful, reflective music. Fade to black.)**


---

